import numpy as np
import cvxpy as cvx

from mpc_formulation import MPCformulation
import pointmass 


class MPCfunapprox(MPCformulation):
    def __init__(self, agent_params, seed=1):
        # Parameters
        self._parse_agent_params(**agent_params)
        
        # Model init
        self.model = getattr(pointmass, self.model_str)()
        self.obs_dim = self.model.obs_space.shape[0]
        self.action_dim = self.model.action_space.shape[0]

        # Actor initilizaiton
        super().__init__(self.model, self.opt_params, self.gamma)

        # Seeded random number generators
        self.rng1 = np.random.default_rng(seed)
        self.rng2 = np.random.default_rng(seed)
        self.rng3 = np.random.default_rng(seed)

        # Parameter values
        self.pf_val = 0.1 * self.rng1.random((self.nPf, 1))
        self.p_val = 0.1 * self.rng1.random((self.nP, 1))

        if "cost_wt" in self.opt_params:
            self.p_val[
                self.iP_cost[0] : self.iP_cost[1]
            ] = self.cost_model.cost_param_init(self.opt_params["cost_wt"])
        self.pf_val[self.iP_cost[1]:], self.p_val[self.iP_cost[1]:] = self.model.model_param_init()  

    def reset(self, obs):
        obs = self.model.get_obs(obs)
        action = np.array(self.action_dim)
        self.X0 = self.model.get_initial_guess(obs, action, self.N)

    def act_forward(self, obs, soln=None, pf_val=None, p_val=None, mode="eval"):
        # Forward policy function evaluation for argmin action
        # Solver params
        obs = self.model.get_obs(obs)
        pf_val = pf_val if pf_val is not None else self.pf_val
        pf_val[: self.obs_dim, :] = obs[:, None]
        # pf_val[
        #     self.obs_dim + self.action_dim : self.obs_dim + 2 * self.action_dim, :
        # ] = (
        #     np.zeros((self.action_dim, 1))
        #     if mode == "train"
        #     else self.rng2.normal(scale=self.eps, size=(self.action_dim, 1))
        # )
        p_val = p_val if p_val is not None else self.p_val
        X0 = soln["x"].full() if soln is not None else self.X0
        # PS: X0 is reinitialized from apriori soln, usually in update routine

        soln = self.pisolver(
            x0=X0,
            p=np.concatenate([pf_val, p_val])[:, 0],
            lbg=self.lbg_vcsd,
            ubg=self.ubg_vcsd,
        )
        fl = self.pisolver.stats()
        # if not fl["success"]:
        #     print("OCP Solver Unsuccessful")

        opt_var = soln["x"].full()
        act0 = opt_var[: self.action_dim, 0]
        act = act0 + self.eps * (self.rng3.random((self.action_dim)) - 0.5)
        act = act.clip(self.model.action_space.low, self.model.action_space.high)

        self.X0 = self.update_X0(opt_var[:, 0])
        info = {
            "optimal": fl["success"],
            "soln": soln.copy(),
            "pf": pf_val.copy(),
            "p": p_val.copy(),
        }
        return act0, info

    def update_X0(self, opt_var):
        # "warm starting" for udpating the initial guess given to the solver
        # based on the last solution
        x0 = opt_var.copy()
        N, an, sn = self.N, self.action_dim, self.obs_dim
        at, st = an * N, sn * N

        x0[: an * (N - 1)] = opt_var[an:at]  # action init
        x0[at : at + sn * (N - 1)] = opt_var[at + sn : at + st]  # state/obs init
        x0[at + st : at + st + sn * (N - 1)] = opt_var[
            at + st + sn : at + 2 * st
        ]  # sigma init
        return x0

    def dPidP(self, soln, pf_val, p_val, optimal=True):
        # Sensitivity of policy output with respect to learnable param
        # i.e. gradient of action wrt to param_val
        x = soln["x"].full()
        lam_g = soln["lam_g"].full()
        z = np.concatenate((x, lam_g), axis=0)
        pf_val = pf_val.copy()
        p_val = p_val.copy()

        if optimal:
            jacob_act = self.dPi(z, pf_val[:, 0], p_val[:, 0]).full()[
                : self.action_dim, :
            ]
        else:
            jacob_act = np.zeros((self.action_dim, self.nP))
        return jacob_act

    def V_value(self, obs, soln=None, pf_val=None, p_val=None, mode="train"):
        # Forward policy function evaluation for argmin action
        # Solver params
        obs = self.model.get_obs(obs)
        pf_val = pf_val if pf_val is not None else self.pf_val
        pf_val[: self.obs_dim, :] = obs[:, None]
        # pf_val[
        #     self.obs_dim + self.action_dim : self.obs_dim + 2 * self.action_dim, :
        # ] = (
        #     np.zeros((self.action_dim, 1))
        #     if mode == "train"
        #     else self.rng2.normal(scale=self.eps, size=(self.action_dim, 1))
        # )
        p_val = p_val if p_val is not None else self.p_val
        X0 = soln["x"].full() if soln is not None else self.model.get_initial_guess(obs, action, self.N)
        # PS: X0 is reinitialized from apriori soln, usually in update routine

        soln = self.pisolver(
            x0=X0,
            p=np.concatenate([pf_val, p_val])[:, 0],
            lbg=self.lbg_vcsd,
            ubg=self.ubg_vcsd,
        )
        fl = self.pisolver.stats()
        if not fl["success"]:
            print("OCP Solver Unsuccessful")

        v_mpc = soln["f"].full()[0, 0]
        info = {
            "optimal": fl["success"],
            "soln": soln.copy(),
            "pf": pf_val.copy(),
            "p": p_val.copy(),
        }
        return v_mpc, info

    def dVdP(self, soln, pf_val, p_val, optimal=True):
        # Gradient of action-value fn Q wrt lernable param
        # state/obs, action, act_wt need to be from qsoln (garbage in garbage out)
        x = soln["x"].full()
        lam_g = soln["lam_g"].full()
        pf_val = pf_val.copy()
        p_val = p_val.copy()
        if optimal:
            _, _, dLdP = self.dLagV(x, lam_g, pf_val[:, 0], p_val[:, 0])
            dLdP = dLdP.full()
        else:
            dLdP = np.zeros((1, self.nP))
        return dLdP

    def Q_value(self, obs, action, soln=None, pf_val=None, p_val=None):
        # Action-value function evaluation
        obs = self.model.get_obs(obs)
        pf_val = pf_val.copy() if pf_val is not None else self.pf_val
        pf_val[: self.obs_dim, :] = obs[:, None]
        pf_val[self.obs_dim : self.obs_dim + self.action_dim, :] = action[:, None]
        # pf_val[
        #     self.obs_dim + self.action_dim : self.obs_dim + 2 * self.action_dim, :
        # ] = np.zeros((self.action_dim, 1))

        p_val = p_val.copy() if p_val is not None else self.p_val
        X0 = (
            soln["x"].full()
            if soln is not None
            else self.model.get_initial_guess(obs, action, self.N)
        )
        X0[: self.action_dim, :] = action[:, None]

        qsoln = self.qsolver(
            x0=X0,
            p=np.concatenate([pf_val, p_val])[:, 0],
            lbg=self.lbg_qcsd,
            ubg=self.ubg_qcsd,
        )
        fl = self.qsolver.stats()
        if not fl["success"]:
            print("OCP Solver Unsuccessful")

        q_mpc = qsoln["f"].full()[0, 0]
        info = {
            "optimal": fl["success"],
            "soln": qsoln.copy(),
            "pf": pf_val.copy(),
            "p": p_val.copy(),
        }
        return q_mpc, info

    def dQdP(self, soln, pf_val, p_val, optimal=True):
        # Gradient of action-value fn Q wrt learnable param
        # state/obs, action, act_wt need to be from qsoln (garbage in garbage out)
        x = soln["x"].full()
        lam_g = soln["lam_g"].full()
        pf_val = pf_val.copy()
        p_val = p_val.copy()
        if optimal:
            _, _, dLdP = self.dLagQ(x, lam_g, pf_val[:, 0], p_val[:, 0])
            dLdP = dLdP.full()
        else:
            dLdP = np.zeros((1, self.nP))
        return dLdP

    def train(self, replay_buffer):
        _ = self.learning_module.train(replay_buffer)
        cost_p = self.p_val[self.iP_cost[0] : self.iP_cost[1]]
        self.cost_model.print_params(cost_p)

    def param_update(self, dJ, param_val=None, constrained_updates=True):
        # Param update scheme
        param_val = param_val if param_val is not None else self.p_val
        if constrained_updates:
            self.p_val = self.constraint_param_update(dJ, param_val)
        else:
            dP = -self.lr[0] * dJ[self.iP_cost[0] : self.iP_cost[1], :]
            self.p_val[self.iP_cost[0] : self.iP_cost[1], :] += dP.clip(
                -self.tr[0], self.tr[0]
            )

    def constraint_param_opt(self, lr, tr):
        # SDP for param update to ensure stable MPC formulation
        # l1, l2 = 0.000, 0.000
        self.dP_th = cvx.Variable((self.nP, 1))
        self.dJ_th = cvx.Parameter((self.nP, 1))
        self.P_th = cvx.Parameter((self.nP, 1))
        P_th_next = self.P_th + self.dP_th

        J_th = 0.5 * cvx.sum_squares(self.dP_th) + lr * self.dJ_th.T @ self.dP_th
        # J_up += l1 * cvx.norm(P_cost_next, 1) + l2 * cvx.norm(P_cost_next, 2)
        constraint = [self.dP_th <= tr, self.dP_th >= -tr]

        self.update_step = cvx.Problem(cvx.Minimize(J_th), constraint)

    def constraint_param_update(self, dJ, p_val):
        # Cost param update
        P_up = p_val.copy()
        self.dJ_th.value = dJ.copy()
        self.P_th.value = P_up.copy()
        try:
            self.update_step.solve()
        except:
            print("SDP solver for cost param update failed")

        if self.update_step.status == "optimal":
            P_up += self.dP_th.value.copy()
        else:
            print(f"Problem status: {self.update_step.status}")
        return P_up


    def _parse_agent_params(self, model_str, opt_params, gamma, eps, learning_params):
        self.model_str = model_str
        self.opt_params = opt_params
        self.gamma = gamma
        self.eps = eps
        self.learning_params = learning_params
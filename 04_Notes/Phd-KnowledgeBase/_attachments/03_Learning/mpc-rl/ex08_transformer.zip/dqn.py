
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from collections import deque
import random
import numpy as np

class Q(nn.Module):
    """ A Q-function network."""
    def __init__(self, state_dim, action_dim, hidden_dim=50):
        super(Q, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, action_dim)

    def forward(self, x):
        x = torch.as_tensor(x).float()
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)
    
    from collections import namedtuple


class DQNAgent:
    def __init__(self, env, gamma, lr=0.001, maxlen=100000, batch_size=64):
        state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.n
        self.env = env
        self.q = Q(state_dim, action_dim)
        self.q_target = Q(state_dim, action_dim)

        self.gamma = gamma
        self.q_optimizer = optim.Adam(self.q.parameters(), lr=lr)
        self.action_dim = action_dim
        self.batch_size = batch_size

        self.replay_buffer = deque(maxlen=maxlen)
    
    def save(self, PATH):
        torch.save(self.q.state_dict(), PATH)

    def load(self, PATH):
        self.q.load_state_dict(torch.load(PATH))
        self.q.eval()
        
    def get_action(self, x, epsilon):
        if np.random.uniform() < epsilon:
            return np.random.randint(self.action_dim)
        return self.q(x).argmax().item()


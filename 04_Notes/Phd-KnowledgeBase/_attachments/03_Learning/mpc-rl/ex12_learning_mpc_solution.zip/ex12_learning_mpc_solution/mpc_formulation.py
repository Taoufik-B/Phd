import numpy as np
import casadi as csd

from quadratic_cost import Quadratic_stage_cost_model

class MPCformulation:
    """
    Class to setup MPC optimization problems in Casadi
    ...

    Attributes
    ----------
    env : Environment

    obs_dim, action_dim : int
        Dimensions of the state and action spaces

    N : int
        Prediction horizon

    gamma : float
        Discount factor

    etau : float
        IPOPT tuning parameter (mu_target, mu_init)

    cost_defn : list of cost types included in parameterization
        Type of cost function (check implemented types)

    model_defn : {"statespace_fromenv", "casadi_fn_obj_fromenv"}
        Source of the model

    X : symbolic (casadi)
        State variables of optimization

    U : symbolic (casadi)
        Input variables of optimization

    Sigma : symbolc (casadi)
        Slack varaibles for state constraints

    Opt_Vars : [X,U,Sigma]

    Pf : symbolic (casadi)
        Optimization parameters [x0, u0]

    P : symbolic (casadi)
        Learnable Optimization parameters (initialized with 0 here)

    model_dyn : casadi function
        Dynamics equation, A*x + B*u, if state space from env is used

    n_P : int
        Number of parameters to be learned

    stage_cost : method
        Predefined method, such as 'quadratic_cost'


    """

    def __init__(self, model, opt_params, gamma):
        self.N = opt_params["horizon"]
        self.gamma = gamma
        self.etau = 1e-6

        ## Symbolic variables for optimization problem
        self.X = csd.MX.sym("X", self.obs_dim, self.N)
        self.U = csd.MX.sym("U", self.action_dim, self.N)
        # Slack variables for state bounds
        self.Sigma = csd.MX.sym("Sigma", self.obs_dim, self.N)

        self.Opt_Vars = csd.vertcat(
            csd.reshape(self.U, -1, 1),
            csd.reshape(self.X, -1, 1),
            csd.reshape(self.Sigma, -1, 1),
        )

        # Symbolic parameters for optimization problem
        self.nPf = self.obs_dim + 2 * self.action_dim
        self.Pf = csd.MX.sym(
            "Pf", self.nPf
        )  # [Initial state x0, action a, eps] ("fixed" params)
        self.nP = 0
        self.P = csd.MX.sym("P", 0)  # Learnable parameters

        # Cost Parameterization and system definition
        self.stage_cost, self.terminal_cost = self.stage_cost_init(
            opt_params["cost_defn"]
        )
        self.model_dyn = self.model_dynamics_init()

        # Optimization formulation with sensitivity (symbolic)
        self.Pi_opt_formulation()
        self.Q_opt_formulation()

    def stage_cost_init(self, cost_defn):
        self.cost_model = Quadratic_stage_cost_model(self.model, cost_defn)
        stage_cost = self.cost_model.stage_cost
        terminal_cost = self.cost_model.terminal_cost
        Pf, P = self.cost_model.Pf, self.cost_model.P
        self.Pf = csd.vertcat(self.Pf, Pf)
        self.iPf_cost = [self.nPf, self.nPf + Pf.shape[0]]
        self.nPf += Pf.shape[0]
        self.P = csd.vertcat(self.P, P)
        self.iP_cost = [self.nP, self.nP + P.shape[0]]
        self.nP += P.shape[0]
        return stage_cost, terminal_cost

    def model_dynamics_init(self):
        model_dyn, Pf, P = self.model.get_model()
        self.Pf = csd.vertcat(self.Pf, Pf)
        self.iPf_dyn = [self.nPf, self.nPf + Pf.shape[0]]
        self.nPf += Pf.shape[0]
        self.P = csd.vertcat(self.P, P)
        self.iP_dyn = [self.nP, self.nP + P.shape[0]]
        self.nP += P.shape[0]
        return model_dyn

    def objective_cost(self):
        W = np.ones((1, self.obs_dim)) * 1e2  # penalty for violations

        # Formulating objective and constraints
        # J = csd.mtimes(
        #     self.U[:, 0].T,
        #     self.Pf[
        #         self.obs_dim + self.action_dim : self.obs_dim + 2 * self.action_dim
        #     ],
        # )
        J = 0.0
        J += self.stage_cost(
            self.Pf[: self.obs_dim],
            self.U[:, 0],
            self.Pf[self.iPf_cost[0] : self.iPf_cost[1], :],
            self.P[self.iP_cost[0] : self.iP_cost[1], :],
        )
        for i in range(self.N - 1):
            J += self.gamma ** (i + 1) * (
                self.stage_cost(
                    self.X[:, i],
                    self.U[:, i + 1],
                    self.Pf[self.iPf_cost[0] : self.iPf_cost[1], :],
                    self.P[self.iP_cost[0] : self.iP_cost[1], :],
                )
                + W @ self.Sigma[:, i]
            )

        J += self.gamma**self.N * (
            self.terminal_cost(
                self.X[:, self.N - 1],
                self.Pf[self.iPf_cost[0] : self.iPf_cost[1], :],
                self.P[self.iP_cost[0] : self.iP_cost[1], :],
            )
            + W @ self.Sigma[:, self.N - 1]
        )
        return J

    def equality_constraints(self):
        g = []  # Equality constrainsts init
        xn = self.model_dyn(
            self.Pf[: self.obs_dim],
            self.U[:, 0],
            self.Pf[self.iPf_dyn[0] : self.iPf_dyn[1], :],
            self.P[self.iP_dyn[0] : self.iP_dyn[1], :],
        )
        for i in range(self.N - 1):
            g.append(self.X[:, i] - xn)
            xn = self.model_dyn(
                self.X[:, i],
                self.U[:, i + 1],
                self.Pf[self.iPf_dyn[0] : self.iPf_dyn[1], :],
                self.P[self.iP_dyn[0] : self.iP_dyn[1], :],
            )
        g.append(self.X[:, self.N - 1] - xn)
        return g

    def inequality_constraints(self):
        # Constraint list init
        hu0 = []  # Bounding constraints on u0
        hu = []  # Box constraints on inputs
        hx = []  # Box constraints on states
        hs = []  # Box constraints on sigma

        # State bounds
        lb_x = self.model.obs_space.low[:, None]
        ub_x = self.model.obs_space.high[:, None]
        lb_u = self.model.action_space.low[:, None]
        ub_u = self.model.action_space.high[:, None]

        hu0.append(lb_u - self.U[:, 0])
        hu0.append(self.U[:, 0] - ub_u)
        for i in range(self.N - 1):
            hx.append(lb_x - self.X[:, i] - self.Sigma[:, i])
            hx.append(self.X[:, i] - ub_x - self.Sigma[:, i])
            hs.append(-self.Sigma[:, i])
            hu.append(lb_u - self.U[:, i + 1])
            hu.append(self.U[:, i + 1] - ub_u)
        hx.append(lb_x - self.X[:, self.N - 1] - self.Sigma[:, self.N - 1])
        hx.append(self.X[:, self.N - 1] - ub_x - self.Sigma[:, self.N - 1])
        hs.append(-self.Sigma[:, self.N - 1])
        return hu0, hu, hx, hs

    def Pi_opt_formulation(self):
        """
        Formulate optimization cost and associated constraints
        - Cost uses stage and terminal cost functions, along with penalties

        """
        # Objective cost
        J = self.objective_cost()

        # Constraints for casadi and limits
        g = self.equality_constraints()
        hu0, hu, hx, hs = self.inequality_constraints()
        G = csd.vertcat(*g)
        Hu = csd.vertcat(*hu0, *hu)
        Hx = csd.vertcat(*hx)
        Hs = csd.vertcat(*hs)
        G_vcsd = csd.vertcat(*g, *hu0, *hu, *hx, *hs)
        lbg = [0] * G.shape[0] + [-np.inf] * (Hu.shape[0] + Hx.shape[0] + Hs.shape[0])
        ubg = [0] * G.shape[0] + [0] * (Hu.shape[0] + Hx.shape[0] + Hs.shape[0])
        self.lbg_vcsd = csd.vertcat(*lbg)
        self.ubg_vcsd = csd.vertcat(*ubg)

        # NLP Problem for value function and policy approximation
        opts_setting = {
            "ipopt.max_iter": 500,
            "ipopt.print_level": 0,
            "print_time": 0,
            "ipopt.mu_target": self.etau,
            "ipopt.mu_init": self.etau,
            "ipopt.acceptable_tol": 1e-6,
            "ipopt.acceptable_obj_change_tol": 1e-6,
        }
        vnlp_prob = {
            "f": J,
            "x": self.Opt_Vars,
            "p": csd.vertcat(self.Pf, self.P),
            "g": G_vcsd,
        }
        self.pisolver = csd.nlpsol("vsolver", "ipopt", vnlp_prob, opts_setting)
        (
            self.Rfun,
            self.dPi,
            self.dLagV,
            self.dRdz,
            self.dRdp,
        ) = self.build_sensitivity(J, G, Hu, Hx, Hs)

    def Q_opt_formulation(self):
        # Objective cost
        J = self.objective_cost()

        # Constraints for casadi and limits
        g = self.equality_constraints()
        _, hu, hx, hs = self.inequality_constraints()
        # NLP problem for Q function approximation
        g.append(self.U[:, 0] - self.Pf[self.obs_dim : self.obs_dim + self.action_dim])
        G = csd.vertcat(*g)
        Hu = csd.vertcat(*hu)
        Hx = csd.vertcat(*hx)
        Hs = csd.vertcat(*hs)
        G_qcsd = csd.vertcat(*g, *hu, *hx, *hs)
        lbg = [0] * G.shape[0] + [-np.inf] * (Hu.shape[0] + Hx.shape[0] + Hs.shape[0])
        ubg = [0] * G.shape[0] + [0] * (Hu.shape[0] + Hx.shape[0] + Hs.shape[0])
        self.lbg_qcsd = csd.vertcat(*lbg)
        self.ubg_qcsd = csd.vertcat(*ubg)

        opts_setting = {
            "ipopt.max_iter": 100,
            "ipopt.print_level": 0,
            "print_time": 0,
            "ipopt.mu_target": self.etau,
            "ipopt.mu_init": self.etau,
            "ipopt.acceptable_tol": 1e-6,
            "ipopt.acceptable_obj_change_tol": 1e-6,
        }
        qnlp_prob = {
            "f": J,
            "x": self.Opt_Vars,
            "p": csd.vertcat(self.Pf, self.P),
            "g": G_qcsd,
        }
        self.qsolver = csd.nlpsol("qsolver", "ipopt", qnlp_prob, opts_setting)
        _, _, self.dLagQ, _, _ = self.build_sensitivity(J, G, Hu, Hx, Hs)

    def build_sensitivity(self, J, G, Hu, Hx, Hs):
        """
        Computes the sensitivity functions for given cost and constraints in
        J, G, Hu, Hx, Hs

        Parameters
        ----------
        J : Cost function

        G : Equality constraints

        Hu : Input Constraints

        Hx : State Constraints

        Hs : Slack constraints


        Returns
        -------
        dPi : TYPE
            DESCRIPTION.
        dLagfunc : TYPE
            DESCRIPTION.
        f_dRdz : TYPE
            DESCRIPTION.
        f_dRdp : TYPE
            DESCRIPTION.

        """
        # Sensitivity
        lamb = csd.MX.sym("lambda", G.shape[0])
        mu_u = csd.MX.sym("muu", Hu.shape[0])
        mu_x = csd.MX.sym("mux", Hx.shape[0])
        mu_s = csd.MX.sym("mus", Hs.shape[0])
        mult = csd.vertcat(lamb, mu_u, mu_x, mu_s)

        # Build Lagrangian
        Lag = (
            J
            + csd.transpose(lamb) @ G
            + csd.transpose(mu_u) @ Hu
            + csd.transpose(mu_x) @ Hx
            + csd.transpose(mu_s) @ Hs
        )
        Lagfunc = csd.Function("Lag", [self.Opt_Vars, mult, self.Pf, self.P], [Lag])

        # Generate sensitivity of the Lagrangian
        dLagfunc = Lagfunc.factory(
            "dLagfunc",
            ["i0", "i1", "i2", "i3"],
            ["jac:o0:i0", "jac:o0:i2", "jac:o0:i3"],
        )
        dLdw, dLdPf, dLdP = dLagfunc(self.Opt_Vars, mult, self.Pf, self.P)

        # Build KKT matrix
        R_kkt = csd.vertcat(
            csd.transpose(dLdw),
            G,
            mu_u * Hu + self.etau,
            mu_x * Hx + self.etau,
            mu_s * Hs + self.etau,
        )

        # z contains all variables of the lagrangian
        z = csd.vertcat(self.Opt_Vars, lamb, mu_u, mu_x, mu_s)

        # Generate sensitivity of the KKT matrix
        Rfun = csd.Function("Rfun", [z, self.Pf, self.P], [R_kkt])
        dR_sensfunc = Rfun.factory("dR", ["i0", "i1", "i2"], ["jac:o0:i0", "jac:o0:i2"])
        [dRdz, dRdP] = dR_sensfunc(z, self.Pf, self.P)

        # Generate sensitivity of the optimal solution
        dzdP = -csd.inv(dRdz)[: self.action_dim, :] @ dRdP
        dPi = csd.Function("dPi", [z, self.Pf, self.P], [dzdP])
        f_dRdz = csd.Function("dRdz", [z, self.Pf, self.P], [dRdz])
        f_dRdp = csd.Function("dRdP", [z, self.Pf, self.P], [dRdP])
        return Rfun, dPi, dLagfunc, f_dRdz, f_dRdp

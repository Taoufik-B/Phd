from acados_template import AcadosModel, AcadosOcp, AcadosOcpSolver, AcadosOcpConstraints

import numpy as np
import casadi as cs
import scipy

from prototype_value_functions import LagrangeFunction, build_cost_functions, build_discrete_dynamics_functions

import matplotlib.pyplot as plt

ACADOS_MULTIPLIER_ORDER = [
    "lbu",
    "lbx",
    "lg",
    "lh",
    "lphi",
    "ubu",
    "ubx",
    "ug",
    "uh",
    "uphi",
    "lsbu",
    "lsbx",
    "lsg",
    "lsh",
    "lsphi",
    "usbu",
    "usbx",
    "usg",
    "ush",
    "usphi",
]

from prototype_value_functions import state_action_value_function, state_value_function


def rename_key_in_dict(d: dict, old_key: str, new_key: str):
    d[new_key] = d.pop(old_key)

    return d


def rename_item_in_list(lst: list, old_item: str, new_item: str):
    if old_item in lst:
        index_old = lst.index(old_item)
        lst[index_old] = new_item

    return lst


def build_constraint_functions(
    ocp: AcadosOcp,
) -> tuple[cs.Function, cs.Function, cs.Function, cs.Function]:
    """
    Build the constraint functions for the OCP.

    Parameters:
        acados_ocp: acados OCP object

    Returns:
        fun_g: stage constraint function
        fun_dg_dp: derivative of stage constraint function with respect to parameters
        fun_g_e: terminal constraint function
        fun_dg_dp_e: derivative of terminal constraint function with respect to parameters
    """
    pass


class LagrangeMultiplierExtractor(object):
    """
    Class to store dimensions of constraints
    """

    order: list = ACADOS_MULTIPLIER_ORDER

    idx_at_stage: list

    def __init__(self, constraints: AcadosOcpConstraints, N: int = 20):
        super().__init__()

        replacements = {
            0: [("lbx", "lbx_0"), ("ubx", "ubx_0")],
            N: [
                ("lbx", "lbx_e"),
                ("ubx", "ubx_e"),
                ("lg", "lg_e"),
                ("ug", "ug_e"),
                ("lh", "lh_e"),
                ("uh", "uh_e"),
                ("lphi", "lphi_e"),
                ("uphi", "uphi_e"),
                ("lsbx", "lsbx_e"),
                ("usbx", "usbx_e"),
                ("lsg", "lsg_e"),
                ("usg", "usg_e"),
                ("lsh", "lsh_e"),
                ("ush", "ush_e"),
                ("lsphi", "lsphi_e"),
                ("usphi", "usphi_e"),
            ],
        }

        idx_at_stage = [dict.fromkeys(self.order, 0) for _ in range(N + 1)]

        for stage, keys in replacements.items():
            for old_key, new_key in keys:
                idx_at_stage[stage] = rename_key_in_dict(idx_at_stage[stage], old_key, new_key)

        # Loop over all constraints and count the number of constraints of each type. Store the indices in a dict.
        for stage, idx in enumerate(idx_at_stage):
            _start = 0
            _end = 0
            for attr in dir(constraints):
                if idx.keys().__contains__(attr):
                    _end += len(getattr(constraints, attr))
                    idx[attr] = slice(_start, _end)
                    _start = _end

        self.idx_at_stage = idx_at_stage

    def get_idx_at_stage(self, stage: int, field: str) -> slice:
        """
        Get the indices of the constraints of the given type at the given stage.

        Parameters:
            stage: stage index
            field: constraint type

        Returns:
            indices: slice object
        """
        return self.idx_at_stage[stage][field]

    def __call__(self, stage: int, field: str, lam: np.ndarray) -> np.ndarray:
        """
        Extract the multipliers at the given stage from the vector of multipliers.

        Parameters:
            stage: stage index
            field: constraint type
            lam: vector of multipliers

        Returns:
            lam: vector of multipliers at the given stage and of the given type
        """
        return lam[self.get_idx_at_stage(stage, field)]


class LagrangeFunction(object):
    """
    Lagrange function for the OCP
    """

    # f_theta: Function
    # ocp: AcadosOcp

    lam_extractor: LagrangeMultiplierExtractor
    fun_f: cs.Function  # Discrete dynamics
    fun_df_dp: cs.Function  # Derivative of discrete dynamics with respect to parameters
    fun_l: cs.Function  # Stage cost
    fun_m: cs.Function  # Terminal cost
    fun_dl_dp: cs.Function  # Derivative of stage cost with respect to parameters
    fun_dm_dp: cs.Function  # Derivative of terminal cost with respect to parameters

    def __init__(self, acados_ocp_solver: AcadosOcpSolver):
        super().__init__()

        self.lam_extractor = LagrangeMultiplierExtractor(
            acados_ocp_solver.acados_ocp.constraints,
            acados_ocp_solver.acados_ocp.dims.N,
        )

        # self.fun_f, self.fun_df_dp = build_discrete_dynamics_functions(acados_ocp_solver.acados_ocp)
        # self.fun_l, self.fun_m, self.fun_dl_dp, self.fun_dm_dp = build_cost_functions(acados_ocp_solver.acados_ocp)
        # _ = build_constraint_functions(acados_ocp_solver.acados_ocp)

    def __call__(self, acados_ocp_solver: AcadosOcpSolver, p: np.ndarray) -> np.float32:
        """
        Evaluate the Lagrange function at the current solution of the OCP.
        """

        res = 0.0

        constraints = acados_ocp_solver.acados_ocp.constraints

        # Initial condition equality constraint
        stage = 0
        res += self.lam_extractor(stage, "lbx_0", acados_ocp_solver.get(stage, "lam")) @ (
            getattr(constraints, "lbx_0") - acados_ocp_solver.get(stage, "x")
        )

        res += self.lam_extractor(stage, "ubx_0", acados_ocp_solver.get(stage, "lam")) @ (
            getattr(constraints, "ubx_0") - acados_ocp_solver.get(stage, "x")
        )

        # Inequality constraints at stage k
        if getattr(constraints, "lbx").size > 0:
            for stage in range(1, acados_ocp_solver.acados_ocp.dims.N):
                res += self.lam_extractor(stage, "lbx", acados_ocp_solver.get(stage, "lam")) @ (
                    getattr(constraints, "lbx") - acados_ocp_solver.get(stage, "x")
                )

        if getattr(constraints, "ubx").size > 0:
            for stage in range(1, acados_ocp_solver.acados_ocp.dims.N):
                res += self.lam_extractor(stage, "ubx", acados_ocp_solver.get(stage, "lam")) @ (
                    getattr(constraints, "ubx") - acados_ocp_solver.get(stage, "x")
                )

        if getattr(constraints, "lbu").size > 0:
            for stage in range(1, acados_ocp_solver.acados_ocp.dims.N):
                res += self.lam_extractor(stage, "lbu", acados_ocp_solver.get(stage, "lam")) @ (
                    getattr(constraints, "lbu") - acados_ocp_solver.get(stage, "u")
                )

        if getattr(constraints, "ubu").size > 0:
            for stage in range(1, acados_ocp_solver.acados_ocp.dims.N):
                res += self.lam_extractor(stage, "ubu", acados_ocp_solver.get(stage, "lam")) @ (
                    getattr(constraints, "ubu") - acados_ocp_solver.get(stage, "u")
                )

        # Terminal state inequality constraints
        stage = acados_ocp_solver.acados_ocp.dims.N
        if getattr(constraints, "lbx_e").size > 0:
            res += self.lam_extractor(stage, "lbx_e", acados_ocp_solver.get(stage, "lam")) @ (
                getattr(constraints, "lbx_e") - acados_ocp_solver.get(stage, "x")
            )

        if getattr(constraints, "ubx_e").size > 0:
            res += self.lam_extractor(stage, "ubx_e", acados_ocp_solver.get(stage, "lam")) @ (
                getattr(constraints, "ubx_e") - acados_ocp_solver.get(stage, "x")
            )

        res += acados_ocp_solver.get_cost()

        res_dyn = 0
        # Dynamic equality constraint
        for stage in range(acados_ocp_solver.acados_ocp.dims.N - 1):
            xf = self.eval_f(
                x=acados_ocp_solver.get(stage, "x"),
                u=acados_ocp_solver.get(stage, "u"),
                p=p,
            )
            xnext = acados_ocp_solver.get(stage + 1, "x")
            pi = acados_ocp_solver.get(stage, "pi")
            res_dyn += pi @ (xf - xnext)

        res += res_dyn

        return res

    def set_fun_f(self, fun_f: cs.Function, fun_df_dp: cs.Function):
        self.fun_f = fun_f
        self.fun_df_dp = fun_df_dp

    def eval_f(self, x: np.ndarray, u: np.ndarray, p: np.ndarray) -> np.ndarray:
        """
        Evaluate the integrator at the current solution of the OCP.

        Parameters:
            x: state
            u: control
            p: parameters

        Returns:
            xf: integrated state
        """
        return self.fun_f(x=x, u=u, p=p)["xf"].full().reshape(-1)

    def eval_df_dp(self, x: np.ndarray, u: np.ndarray, p: np.ndarray) -> np.ndarray:
        """
        Evaluate the gradient of the integrator with respect to the parameters at the current solution of the OCP.

        Parameters:
            x: state
            u: control
            p: parameters

        Returns:
            df_dp: gradient of the integrator with respect to the parameters
        """
        return self.fun_df_dp(x=x, u=u, p=p)["dxf_dp"].full()

    def eval_dL_dp(self, acados_ocp_solver: AcadosOcpSolver, p: np.ndarray) -> np.ndarray:
        """
        Evaluate the gradient of the Lagrange function with respect to the parameters at the current solution of the OCP.

        Parameters:
            acados_ocp_solver: acados OCP solver object with the current solution
            p: parameters

        Returns:
            dL_dp: gradient of the Lagrange function with respect to the parameters
        """

        res = 0
        # Dynamic equality constraint
        for stage in range(acados_ocp_solver.acados_ocp.dims.N - 1):
            x = acados_ocp_solver.get(stage, "x")
            u = acados_ocp_solver.get(stage, "u")
            pi = acados_ocp_solver.get(stage, "pi")
            res += pi @ self.eval_df_dp(x=x, u=u, p=p)

        return res


def export_pointmass_discrete_model() -> AcadosModel:
    """
    :return: acados ocp model for point mass
    """

    model = AcadosModel()

    # Model dynamics
    dt = 0.1
    m = 1.0
    A = np.array(
        [
            [1.0, 0.0, dt, 0.0],
            [0.0, 1.0, 0.0, dt],
            [0.0, 0.0, 0.9, 0.0],
            [0.0, 0.0, 0.0, 0.9],
        ]
    )
    B = np.array([[0.0, 0.0], [0.0, 0.0], [dt / m, 0.0], [0.0, dt / m]])

    # set up states & controls
    x = cs.SX.sym("x", 4)
    u = cs.SX.sym("u", 2)

    # dynamics
    model.x = x
    model.u = u
    model.disc_dyn_expr = cs.mtimes(A, x) + cs.mtimes(B, u)
    model.name = "pointmass"

    return model


def export_parametric_pointmass_discrete_model() -> AcadosModel:
    """
    :return: acados ocp model for point mass
    """

    model = AcadosModel()

    # Model dynamics
    dt = 0.1
    m = 1.0
    A = cs.SX.sym("A", 4, 4)
    B = cs.SX.sym("B", 4, 2)

    p = cs.vertcat(cs.reshape(A.T, -1, 1), cs.reshape(B.T, -1, 1))

    # set up states & controls
    x = cs.SX.sym("x", 4)
    u = cs.SX.sym("u", 2)

    # dynamics
    model.x = x
    model.u = u
    model.p = p
    model.disc_dyn_expr = cs.mtimes(A, x) + cs.mtimes(B, u)
    model.name = "pointmass"

    return model


def export_acados_ocp(N_horizon: int = 50, T_horizon: float = 1.0) -> AcadosOcp:
    # create ocp object to formulate the OCP
    ocp = AcadosOcp()

    model = export_pointmass_discrete_model()

    # set model
    # ocp.parameter_values = np.array([1.0])
    ocp.model = model

    # set dimensions
    ocp.dims.N = N_horizon
    nu = ocp.model.u.size()[0]
    nx = ocp.model.x.size()[0]

    # set cost
    Q_mat = 2 * np.diag([1e3, 1e3, 1e-2, 1e-2])
    R_mat = 2 * np.diag([1e-1, 1e-1])

    # We use the NONLINEAR_LS cost type and GAUSS_NEWTON Hessian approximation - One can also use the external cost module to specify generic cost.
    ocp.cost.cost_type = "NONLINEAR_LS"
    ocp.cost.cost_type_e = "NONLINEAR_LS"
    ocp.cost.W = scipy.linalg.block_diag(Q_mat, R_mat)
    ocp.cost.W_e = Q_mat

    ocp.model.cost_y_expr = cs.vertcat(model.x, model.u)
    ocp.model.cost_y_expr_e = model.x
    ocp.cost.yref = np.zeros((nx + nu,))
    ocp.cost.yref_e = np.zeros((nx,))

    # self.obs_space = Box(
    #     low=np.array([-2.0, -2.0, -10.0, -10.0]),
    #     high=np.array([2.0, 2.0, 10.0, 10.0], dtype=np.float32),
    # )
    # self.action_space = Box(low=-1.0, high=1.0, shape=(2,), dtype=np.float32)

    # set state constraints
    ocp.constraints.lbx = np.array([-2.0, -2.0, -10.0, -10.0])
    ocp.constraints.ubx = np.array([+2.0, +2.0, +10.0, +10.0])
    ocp.constraints.idxbx = np.array([0, 1, 2, 3])

    # set inputconstraints
    ocp.constraints.lbu = np.array([-1.0, -1.0])
    ocp.constraints.ubu = np.array([+1.0, +1.0])
    ocp.constraints.idxbu = np.array([0, 1])

    ocp.constraints.x0 = np.array([1.0, 1.0, 0.0, 0.0])

    # set options
    ocp.solver_options.qp_solver = "PARTIAL_CONDENSING_HPIPM"  # FULL_CONDENSING_QPOASES
    # PARTIAL_CONDENSING_HPIPM, FULL_CONDENSING_QPOASES, FULL_CONDENSING_HPIPM,
    # PARTIAL_CONDENSING_QPDUNES, PARTIAL_CONDENSING_OSQP, FULL_CONDENSING_DAQP
    ocp.solver_options.hessian_approx = "GAUSS_NEWTON"  # 'GAUSS_NEWTON', 'EXACT'
    ocp.solver_options.integrator_type = "DISCRETE"
    # ocp.solver_options.print_level = 1
    ocp.solver_options.nlp_solver_type = "SQP"  # SQP_RTI, SQP
    ocp.solver_options.nlp_solver_max_iter = 400
    # ocp.solver_options.levenberg_marquardt = 1e-4

    # set prediction horizon
    ocp.solver_options.tf = T_horizon

    return ocp


def export_parametric_ocp(p_nominal: np.array, N_horizon: int = 50, T_horizon: float = 1.0) -> AcadosOcp:
    # create ocp object to formulate the OCP
    ocp = AcadosOcp()

    model = export_parametric_pointmass_discrete_model()

    # set model
    # ocp.parameter_values = np.array([1.0])
    ocp.model = model

    # set dimensions
    ocp.dims.N = N_horizon
    nu = ocp.model.u.size()[0]
    nx = ocp.model.x.size()[0]

    # set cost
    Q_mat = 2 * np.diag([1e3, 1e3, 1e-2, 1e-2])
    R_mat = 2 * np.diag([1e-1, 1e-1])

    # We use the NONLINEAR_LS cost type and GAUSS_NEWTON Hessian approximation - One can also use the external cost module to specify generic cost.
    ocp.cost.cost_type = "NONLINEAR_LS"
    ocp.cost.cost_type_e = "NONLINEAR_LS"
    ocp.cost.W = scipy.linalg.block_diag(Q_mat, R_mat)
    ocp.cost.W_e = Q_mat

    ocp.model.cost_y_expr = cs.vertcat(model.x, model.u)
    ocp.model.cost_y_expr_e = model.x
    ocp.cost.yref = np.zeros((nx + nu,))
    ocp.cost.yref_e = np.zeros((nx,))

    # set state constraints
    ocp.constraints.lbx = np.array([-2.0, -2.0, -10.0, -10.0])
    ocp.constraints.ubx = np.array([+2.0, +2.0, +10.0, +10.0])
    ocp.constraints.idxbx = np.array([0, 1, 2, 3])

    # set inputconstraints
    ocp.constraints.lbu = np.array([-1.0, -1.0])
    ocp.constraints.ubu = np.array([+1.0, +1.0])
    ocp.constraints.idxbu = np.array([0, 1])

    ocp.constraints.x0 = np.array([1.0, 1.0, 0.0, 0.0])

    ocp.parameter_values = p_nominal

    # set options
    ocp.solver_options.qp_solver = "PARTIAL_CONDENSING_HPIPM"  # FULL_CONDENSING_QPOASES
    # PARTIAL_CONDENSING_HPIPM, FULL_CONDENSING_QPOASES, FULL_CONDENSING_HPIPM,
    # PARTIAL_CONDENSING_QPDUNES, PARTIAL_CONDENSING_OSQP, FULL_CONDENSING_DAQP
    ocp.solver_options.hessian_approx = "GAUSS_NEWTON"  # 'GAUSS_NEWTON', 'EXACT'
    ocp.solver_options.integrator_type = "DISCRETE"
    # ocp.solver_options.print_level = 1
    ocp.solver_options.nlp_solver_type = "SQP"  # SQP_RTI, SQP
    ocp.solver_options.nlp_solver_max_iter = 400
    # ocp.solver_options.levenberg_marquardt = 1e-4

    # set prediction horizon
    ocp.solver_options.tf = T_horizon

    return ocp


def export_parametric_q_ocp(p_nominal: np.array, N_horizon: int = 50, T_horizon: float = 1.0) -> AcadosOcp:
    # create ocp object to formulate the OCP
    ocp = AcadosOcp()

    model = export_parametric_pointmass_discrete_model()

    # set model
    # ocp.parameter_values = np.array([1.0])
    ocp.model = model

    # set dimensions
    ocp.dims.N = N_horizon
    nu = ocp.model.u.size()[0]
    nx = ocp.model.x.size()[0]

    # set cost
    Q_mat = 2 * np.diag([1e3, 1e3, 1e-2, 1e-2])
    R_mat = 2 * np.diag([1e-1, 1e-1])

    # We use the NONLINEAR_LS cost type and GAUSS_NEWTON Hessian approximation - One can also use the external cost module to specify generic cost.
    ocp.cost.cost_type = "NONLINEAR_LS"
    ocp.cost.cost_type_e = "NONLINEAR_LS"
    ocp.cost.W = scipy.linalg.block_diag(Q_mat, R_mat)
    ocp.cost.W_e = Q_mat

    ocp.model.cost_y_expr = cs.vertcat(model.x, model.u)
    ocp.model.cost_y_expr_e = model.x
    ocp.cost.yref = np.zeros((nx + nu,))
    ocp.cost.yref_e = np.zeros((nx,))

    # set state constraints
    ocp.constraints.lbx = np.array([-2.0, -2.0, -10.0, -10.0])
    ocp.constraints.ubx = np.array([+2.0, +2.0, +10.0, +10.0])
    ocp.constraints.idxbx = np.array([0, 1, 2, 3])

    # set inputconstraints
    ocp.constraints.lbu = np.array([-1.0, -1.0])
    ocp.constraints.ubu = np.array([+1.0, +1.0])
    ocp.constraints.idxbu = np.array([0, 1])
    ocp.constraints.idxsbu = np.array([0, 1])

    ocp.cost.Zl = 1e2 * np.array([1.0, 1.0])
    ocp.cost.Zu = 1e2 * np.array([1.0, 1.0])
    ocp.cost.zl = 1e2 * np.array([0.0, 0.0])
    ocp.cost.zu = 1e2 * np.array([0.0, 0.0])

    ocp.constraints.x0 = np.array([1.0, 1.0, 0.0, 0.0])

    ocp.parameter_values = p_nominal

    # set options
    ocp.solver_options.qp_solver = "PARTIAL_CONDENSING_HPIPM"  # FULL_CONDENSING_QPOASES
    # PARTIAL_CONDENSING_HPIPM, FULL_CONDENSING_QPOASES, FULL_CONDENSING_HPIPM,
    # PARTIAL_CONDENSING_QPDUNES, PARTIAL_CONDENSING_OSQP, FULL_CONDENSING_DAQP
    ocp.solver_options.hessian_approx = "GAUSS_NEWTON"  # 'GAUSS_NEWTON', 'EXACT'
    ocp.solver_options.integrator_type = "DISCRETE"
    # ocp.solver_options.print_level = 1
    # ocp.solver_options.nlp_solver_type = "SQP"  # SQP_RTI, SQP
    ocp.solver_options.nlp_solver_type = "SQP"  # SQP_RTI, SQP
    ocp.solver_options.nlp_solver_max_iter = 400
    # ocp.solver_options.levenberg_marquardt = 1e-4

    # set prediction horizon
    ocp.solver_options.tf = T_horizon

    return ocp


def test_nominal_pointmass_mpc(x0: np.ndarray = np.array([1.0, 1.0, 0.0, 0.0])):
    ocp = export_acados_ocp()

    acados_solver = AcadosOcpSolver(ocp, json_file="acados_ocp.json")

    _ = acados_solver.solve_for_x0(x0)

    for stage in range(ocp.dims.N):
        print(f"stage {stage} : {acados_solver.get(stage, 'x')}")


def test_parametric_pointmass_mpc(x0: np.ndarray = np.array([1.0, 1.0, 0.0, 0.0])):
    dt = 0.1
    m = 1.0
    A = np.array(
        [
            [1.0, 0.0, dt, 0.0],
            [0.0, 1.0, 0.0, dt],
            [0.0, 0.0, 0.9, 0.0],
            [0.0, 0.0, 0.0, 0.9],
        ]
    )
    B = np.array([[0.0, 0.0], [0.0, 0.0], [dt / m, 0.0], [0.0, dt / m]])

    p = np.concatenate([A.reshape(-1, 1), B.reshape(-1, 1)])

    ocp = export_parametric_ocp(p_nominal=p)

    # create solver
    acados_solver = AcadosOcpSolver(ocp, json_file="acados_ocp.json")

    for stage in range(ocp.dims.N):
        acados_solver.set(stage, "p", p)

    _ = acados_solver.solve_for_x0(x0)

    for stage in range(ocp.dims.N):
        print(f"stage {stage} : {acados_solver.get(stage, 'x')}")


def test_model_sensitivity(x0: np.ndarray = np.array([1.0, 1.0, 0.0, 0.0])):
    dt = 0.1
    m = 1.0
    A = np.array(
        [
            [1.0, 0.0, dt, 0.0],
            [0.0, 1.0, 0.0, dt],
            [0.0, 0.0, 0.9, 0.0],
            [0.0, 0.0, 0.0, 0.9],
        ]
    )
    B = np.array([[0.0, 0.0], [0.0, 0.0], [dt / m, 0.0], [0.0, dt / m]])

    p_nominal = np.concatenate([A.reshape(-1, 1), B.reshape(-1, 1)])

    ocp = export_parametric_ocp(p_nominal=p_nominal)

    fun = {}
    fun["f"] = cs.Function(
        "f", [ocp.model.x, ocp.model.u, ocp.model.p], [ocp.model.disc_dyn_expr], ["x", "u", "p"], ["xf"]
    )
    fun["df_dp"] = cs.Function(
        "df_dp",
        [ocp.model.x, ocp.model.u, ocp.model.p],
        [cs.jacobian(ocp.model.disc_dyn_expr, ocp.model.p)],
        ["x", "u", "p"],
        ["dxf_dp"],
    )

    acados_ocp_solver = AcadosOcpSolver(ocp, json_file="acados_ocp.json")

    lagrange_function = LagrangeFunction(acados_ocp_solver)

    lagrange_function.set_fun_f(fun["f"], fun["df_dp"])

    _ = acados_ocp_solver.solve_for_x0(x0)

    # Generate test parameters
    p_test = []

    idx_var = -9
    dp = 0.001
    p_variation = np.arange(0.7, 0.9, dp)
    N_test = len(p_variation)
    p_test = np.array([p_nominal.reshape(-1) for _ in range(N_test)])
    p_test[:, idx_var] = p_variation

    L = np.zeros(len(p_test))
    dL_dp = np.zeros((len(p_test), len(p_nominal)))

    lagrange_function(acados_ocp_solver, p_nominal)

    lagrange_function.eval_dL_dp(acados_ocp_solver, p_nominal)

    for i, p_i in enumerate(p_test):
        for stage in range(acados_ocp_solver.acados_ocp.dims.N):
            acados_ocp_solver.set(stage, "p", p_i)

        _ = acados_ocp_solver.solve_for_x0(x0)

        L[i] = lagrange_function(acados_ocp_solver, p_i)
        dL_dp[i, :] = lagrange_function.eval_dL_dp(acados_ocp_solver, p_i)

    dL_dp = dL_dp[:, idx_var]
    dL_dp_grad = np.gradient(L, dp)

    L_reconstructed = np.cumsum(dL_dp) * dp + L[0]
    constant = L[0] - L_reconstructed[0]
    L_reconstructed += constant

    L_reconstructed_np_grad = np.cumsum(dL_dp_grad) * dp + L[0]
    constant = L[0] - L_reconstructed_np_grad[0]
    L_reconstructed_np_grad += constant

    if True:
        _, ax = plt.subplots(nrows=2, ncols=1, sharex=True)
        ax[0].plot(p_variation, L)
        ax[0].plot(p_variation, L_reconstructed, "--")
        ax[0].plot(p_variation, L_reconstructed_np_grad, "-.")
        ax[1].legend(["L", "L integrate dL_dp", "L_integrate np.grad"])
        ax[1].plot(p_variation, dL_dp)
        ax[1].plot(p_variation, dL_dp_grad, "--")
        ax[1].legend(["algorithmic differentiation", "np.grad"])
        ax[0].set_ylabel("L")
        ax[1].set_ylabel("dL_dp")
        ax[1].set_xlabel("p")
        ax[0].grid(True)
        ax[1].grid(True)

        plt.show()

    return int(not np.allclose(dL_dp, dL_dp_grad, rtol=1e-2, atol=1e-2))


def state_action_value_function(
    acados_ocp_solver: AcadosOcpSolver,
    state: np.ndarray,
    action: np.ndarray,
) -> float:
    """
    Evaluate the action-value function at the given state and action.

    Parameters:
        acados_ocp_solver: acados OCP solver object
        state: state
        a: action

    Returns:
        float: action-value function value
    """

    acados_ocp_solver.set(0, "x", state)
    acados_ocp_solver.set(0, "u", action)
    acados_ocp_solver.constraints_set(0, "lbx", state)
    acados_ocp_solver.constraints_set(0, "ubx", state)
    acados_ocp_solver.constraints_set(0, "lbu", action)
    acados_ocp_solver.constraints_set(0, "ubu", action)

    status = acados_ocp_solver.solve()

    if status != 0:
        raise Exception(f"acados acados_ocp_solver returned status {status} Exiting.")

    return acados_ocp_solver.get_cost()


def test_q_ocp(x0: np.ndarray = np.array([1.0, 1.0, 0.0, 0.0])):
    dt = 0.1
    m = 1.0
    A = np.array(
        [
            [1.0, 0.0, dt, 0.0],
            [0.0, 1.0, 0.0, dt],
            [0.0, 0.0, 0.9, 0.0],
            [0.0, 0.0, 0.0, 0.9],
        ]
    )
    B = np.array([[0.0, 0.0], [0.0, 0.0], [dt / m, 0.0], [0.0, dt / m]])

    p_nominal = np.concatenate([A.reshape(-1, 1), B.reshape(-1, 1)])

    ocp = export_parametric_q_ocp(p_nominal=p_nominal)

    fun = {}
    fun["f"] = cs.Function(
        "f", [ocp.model.x, ocp.model.u, ocp.model.p], [ocp.model.disc_dyn_expr], ["x", "u", "p"], ["xf"]
    )
    fun["df_dp"] = cs.Function(
        "df_dp",
        [ocp.model.x, ocp.model.u, ocp.model.p],
        [cs.jacobian(ocp.model.disc_dyn_expr, ocp.model.p)],
        ["x", "u", "p"],
        ["dxf_dp"],
    )

    acados_ocp_solver = AcadosOcpSolver(ocp, json_file="acados_q_ocp.json")

    lagrange_function = LagrangeFunction(acados_ocp_solver)

    lagrange_function.set_fun_f(fun["f"], fun["df_dp"])

    # _ = acados_ocp_solver.solve_for_x0(x0)

    action = np.array([0.1, 0.1])

    state = x0

    q = state_action_value_function(acados_ocp_solver, state, action)

    # Generate test parameters
    p_test = []

    idx_var = -9
    dp = 0.001
    p_variation = np.arange(0.7, 0.9, dp)
    N_test = len(p_variation)
    p_test = np.array([p_nominal.reshape(-1) for _ in range(N_test)])
    p_test[:, idx_var] = p_variation

    Q = np.zeros(len(p_test))
    dQ_dp = np.zeros((len(p_test), len(p_nominal)))

    lagrange_function(acados_ocp_solver, p_nominal)

    lagrange_function.eval_dL_dp(acados_ocp_solver, p_nominal)

    for i, p_i in enumerate(p_test):
        for stage in range(acados_ocp_solver.acados_ocp.dims.N):
            acados_ocp_solver.set(stage, "p", p_i)

        _ = acados_ocp_solver.solve_for_x0(x0)

        Q[i] = state_action_value_function(acados_ocp_solver, state, action)
        dQ_dp[i, :] = lagrange_function.eval_dL_dp(acados_ocp_solver, p_i)

    dQ_dp = dQ_dp[:, idx_var]
    dQ_dp_grad = np.gradient(Q, dp)

    Q_reconstructed = np.cumsum(dQ_dp) * dp + Q[0]
    constant = Q[0] - Q_reconstructed[0]
    Q_reconstructed += constant

    Q_reconstructed_np_grad = np.cumsum(dQ_dp_grad) * dp + Q[0]
    constant = Q[0] - Q_reconstructed_np_grad[0]
    Q_reconstructed_np_grad += constant

    if True:
        _, ax = plt.subplots(nrows=2, ncols=1, sharex=True)
        ax[0].plot(p_variation, Q)
        ax[0].plot(p_variation, Q_reconstructed, "--")
        ax[0].plot(p_variation, Q_reconstructed_np_grad, "-.")
        ax[1].legend(["Q", "Q integrate dL_dp", "Q_integrate np.grad"])
        ax[1].plot(p_variation, dQ_dp)
        ax[1].plot(p_variation, dQ_dp_grad, "--")
        ax[1].legend(["algorithmic differentiation", "np.grad"])
        ax[0].set_ylabel("Q")
        ax[1].set_ylabel("dQ_dp")
        ax[1].set_xlabel("p")
        ax[0].grid(True)
        ax[1].grid(True)

        plt.show()

    return int(not np.allclose(dQ_dp, dQ_dp_grad, rtol=1e-2, atol=1e-2))


def test_dV_dp(x0: np.ndarray = np.array([1.0, 1.0, 0.0, 0.0])):
    pass


# Basic setup
import numpy as np
import casadi as csd

import pointmass
from mpc import MPCfunapprox
from replay_buffer import BasicBuffer, ReplayBuffer

from opt_formulation import Optformulation
from mpc import MPCfunapprox


class MPCfunapprox_ex(MPCfunapprox, Optformulation):
    def __init__(self, agent_params, seed=1):
        # Parameters
        self._parse_agent_params(**agent_params)

        # Model init
        self.model = getattr(pointmass, self.model_str)()
        self.obs_dim = self.model.obs_space.shape[0]
        self.action_dim = self.model.action_space.shape[0]

        # MPC initilizaiton
        Optformulation.__init__(self, self.model, self.opt_params, self.gamma)

        # Seeded random number generators
        self.rng1 = np.random.default_rng(seed)
        self.rng2 = np.random.default_rng(seed)
        self.rng3 = np.random.default_rng(seed)

        # Parameter values
        self.pf_val = 0.1 * self.rng1.random((self.nPf, 1))
        self.p_val = 0.1 * self.rng1.random((self.nP, 1))
        if "cost_wt" in self.opt_params:
            self.p_val[self.iP_cost[0] : self.iP_cost[1]] = self.cost_model.cost_param_init(self.opt_params["cost_wt"])
        self.pf_val[self.iP_cost[1] :], self.p_val[self.iP_cost[1] :] = self.model.model_param_init()

        # initiate the learning module
        self.learning_module = Qlearning(self, self.learning_params, seed)
        self.constraint_param_opt(self.learning_module.lr, self.learning_module.tr)


class Qlearning:
    def __init__(self, ocp, learning_params, seed):
        # hyperparameters
        self.ocp = ocp
        self._parse_agent_params(**learning_params)

    def train(self, replay_buffer: ReplayBuffer):
        """
        Updates Qfn parameters by using (random) data from replay_buffer

        Parameters
        ----------
        replay_buffer : ReplayBuffer object
            Class instance containing all past data

        Returns
        -------
        dict : {l_theta: parameters of Qfn,
                TD_error: observed TD_error}

        """
        td_avg = 0
        batch_size = min(self.batch_size, replay_buffer.size)
        train_it = min(self.iterations, int(3.0 * replay_buffer.size / batch_size))
        p_val = self.ocp.p_val.copy()

        for it in range(train_it):
            (
                _,
                obss,
                actions,
                rewards,
                _,
                next_obss,
                infos,
            ) = replay_buffer.sample(batch_size)
            if not it % 3:
                p_val = self.ocp.p_val.copy()

            del_J = 0.0
            for j, o in enumerate(obss):
                a = actions[j]
                # q, info = self.ocp.Q_value(o, a, soln=infos[j]["soln"], pf_val=infos[j]["pf"])
                q, _ = self.ocp.Q_value(o, a)
                # _, info_next = self.ocp.act_forward(
                #     next_obss[j], soln=infos[j]["soln"], pf_val=infos[j]["pf"], p_val=p_val, mode="update"
                # )
                # v_next = info_next["soln"]["f"].full()[0, 0]
                v_next = self.ocp.V_value(next_obss[j])

                td_target = rewards[j][0] + self.ocp.gamma * v_next - q

                # grad_q = self.ocp.dQdP(info["soln"], info["pf"], info["p"])
                grad_q = self.ocp.dQdP()

                del_J -= td_target * grad_q.T
                td_avg += td_target

            # Param update
            self.ocp.p_val -= self.lr * (del_J.reshape(-1, 1) / batch_size)

            self.ocp.update_parameters(self.ocp.p_val)

            # self.ocp.param_update(del_J / batch_size, constrained_updates=False)
        # print info
        print(f"Averaged TD error: {td_avg / train_it}")

        return {
            "l_theta": self.ocp.p_val,
            "TD_error": td_avg / train_it,
        }

    def _parse_agent_params(self, lr, tr, train_params, constrained_updates=False):
        self.lr = lr
        self.tr = tr
        self.iterations = train_params["iterations"]
        self.batch_size = train_params["batch_size"]
        self.constrained_updates = constrained_updates


class MPC(object):
    """MPC for a point mass system."""

    def __init__(self, agent_params, seed=1):
        super(MPC, self).__init__()

        dt = 0.1
        m = 1.0
        A = np.array(
            [
                [1.0, 0.0, dt, 0.0],
                [0.0, 1.0, 0.0, dt],
                [0.0, 0.0, 0.9, 0.0],
                [0.0, 0.0, 0.0, 0.9],
            ]
        )
        B = np.array([[0.0, 0.0], [0.0, 0.0], [dt / m, 0.0], [0.0, dt / m]])

        p_nominal = np.concatenate([A.reshape(-1, 1), B.reshape(-1, 1)])

        self.p_val = p_nominal.copy()

        self.ocp = export_parametric_ocp(p_nominal=p_nominal)
        self.ocp_solver = AcadosOcpSolver(self.ocp, json_file="acados_ocp.json")

        self.q_ocp = export_parametric_q_ocp(p_nominal=p_nominal)
        self.q_ocp_solver = AcadosOcpSolver(self.q_ocp, json_file="acados_q_ocp.json")

        for solver in [self.ocp_solver, self.q_ocp_solver]:
            for stage in range(self.ocp_solver.acados_ocp.dims.N):
                solver.set(stage, "p", p_nominal)

        fun = {}
        fun["f"] = cs.Function(
            "f",
            [self.ocp.model.x, self.ocp.model.u, self.ocp.model.p],
            [self.ocp.model.disc_dyn_expr],
            ["x", "u", "p"],
            ["xf"],
        )
        fun["df_dp"] = cs.Function(
            "df_dp",
            [self.ocp.model.x, self.ocp.model.u, self.ocp.model.p],
            [cs.jacobian(self.ocp.model.disc_dyn_expr, self.ocp.model.p)],
            ["x", "u", "p"],
            ["dxf_dp"],
        )

        self.lagrange_function = LagrangeFunction(self.ocp_solver)

        self.lagrange_function.set_fun_f(fun["f"], fun["df_dp"])

        self._parse_agent_params(**agent_params)

        # Model init
        # self.model = getattr(pointmass, self.model_str)()
        self.obs_dim = 4
        self.action_dim = 2

        # MPC initilizaiton
        # Optformulation.__init__(self, self.model, self.opt_params, self.gamma)

        # Seeded random number generators
        self.rng1 = np.random.default_rng(seed)
        self.rng2 = np.random.default_rng(seed)
        self.rng3 = np.random.default_rng(seed)

        # Parameter values
        # self.pf_val = 0.1 * self.rng1.random((self.nPf, 1))
        # self.p_val = 0.1 * self.rng1.random((self.nP, 1))
        # if "cost_wt" in self.opt_params:
        #     self.p_val[self.iP_cost[0] : self.iP_cost[1]] = self.cost_model.cost_param_init(self.opt_params["cost_wt"])
        # self.pf_val[self.iP_cost[1] :], self.p_val[self.iP_cost[1] :] = self.model.model_param_init()

        # initiate the learning module
        self.learning_module = Qlearning(self, self.learning_params, seed)

        # TODO: Check with Shambhu why called here
        # self.constraint_param_opt(self.learning_module.lr, self.learning_module.tr)

    def act_forward(self, state: np.ndarray, mode: str = "eval") -> np.ndarray:
        return self.ocp_solver.solve_for_x0(state), None

    def V_value(self, state: np.ndarray) -> float:
        return state_value_function(self.ocp_solver, state)

    def Q_value(self, state: np.ndarray, action: np.ndarray):
        return state_action_value_function(self.q_ocp_solver, state, action), None

    def dQdP(self) -> np.ndarray:
        return self.lagrange_function.eval_dL_dp(self.q_ocp_solver, self.p_val)

    def reset(self, state: np.ndarray):
        for solver in [self.ocp_solver, self.q_ocp_solver]:
            for stage in range(self.ocp_solver.acados_ocp.dims.N):
                solver.set(stage, "x", state)
                solver.set(stage, "u", np.zeros(solver.acados_ocp.dims.nu))

    def set_learning_module(self, learning_module):
        self.learning_module = learning_module

    def train(self, replay_buffer: ReplayBuffer) -> None:
        _ = self.learning_module.train(replay_buffer)

    def _parse_agent_params(self, model_str, opt_params, gamma, eps, learning_params):
        self.model_str = model_str
        self.opt_params = opt_params
        self.gamma = gamma
        self.eps = eps
        self.learning_params = learning_params

    def update_parameters(self, p_val: np.ndarray) -> None:
        self.p_val = p_val.copy()
        for solver in [self.ocp_solver, self.q_ocp_solver]:
            for stage in range(self.ocp_solver.acados_ocp.dims.N):
                solver.set(stage, "p", p_val)

    # def param_update(self, del_J: np.ndarray, constrained_updates: bool = False) -> None:
    #     self.p_val -= self.learning_module.lr * del_J.reshape(-1, 1)


def q_learning():
    obs_dim, action_dim = 4, 2
    seed = 1
    env_str = "PointMass"
    env_params = {"start_loc": [1.0, 1.0, 0.0, 0.0], "init_std": 0.2, "step_std": 0.05, "stochasticity": 1.0}
    agent_params = {
        "gamma": 0.95,
        "model_str": "pointmass_v1_model",
        "opt_params": {"cost_defn": ["fullW", "fullR"], "cost_wt": [[1.0, 1.0, 1.0, 1.0], [0.1, 0.1]], "horizon": 10},
        "eps": 0.25,
        "learning_params": {
            "lr": 3e-4,
            "tr": 0.2,
            "train_params": {"iterations": 50, "batch_size": 32},
            "constrained_updates": True,
        },
    }
    n_iterations = 50
    n_trains = 1
    n_evals = 0
    n_steps = 50
    max_len_buffer = 50

    # Additional functions
    def rollout_sample(env, agent, mode="train"):
        state, obs = env.reset()
        agent.reset(obs)
        rollout_return = 0
        rollout_buffer = BasicBuffer()

        for _ in range(n_steps):
            action, add_info = agent.act_forward(obs, mode=mode)
            next_state, next_obs, reward, _ = env.step(action)
            if mode == "train":
                rollout_buffer.push(state, obs, action, reward, next_state, next_obs, add_info)
            rollout_return += reward
            state = next_state.copy()
            obs = next_obs.copy()
        return rollout_return, rollout_buffer

    # Experiment init
    env = getattr(pointmass, env_str)("PointMass", env_params, seed)
    replay_buffer = ReplayBuffer(max_len_buffer, seed)

    # Agent init
    # agent = MPCfunapprox_ex(agent_params, seed)
    agent = MPC(agent_params, seed)
    # Test run
    _, obs = env.reset()
    agent.reset(obs)
    act0, _ = agent.act_forward(obs)

    # main loop
    for it in range(n_iterations):
        print(f"Iteration: {it}")
        t_returns, e_returns = [], []

        # training rollouts
        for _ in range(n_trains):
            rollout_return, rollout_buffer = rollout_sample(env, agent, mode="train")
            replay_buffer.push(rollout_buffer.buffer)
            t_returns.append(rollout_return)

        # agent training
        agent.train(replay_buffer)

        # training rollouts
        for _ in range(n_evals):
            rollout_return, rollout_buffer = rollout_sample(env, agent, mode="eval")
            e_returns.append(rollout_return)

        print(f"Training rollout return: {np.mean(t_returns)}")
        # print(f"Evaluation rollout return: {np.mean(e_returns)}")

    # final rollouts
    f_returns = []
    for _ in range(100):
        rollout_return, rollout_buffer = rollout_sample(env, agent, mode="final")
        f_returns.append(rollout_return)
    print(f"Final rollout return: {np.mean(f_returns)}")


def test_MPC():
    mpc = MPC()


def test_q_learning():
    q_learning()


def test_closed_loop():
    def rollout_sample(env, agent, n_steps=50, mode="train"):
        state, obs = env.reset()
        agent.reset(obs)
        rollout_return = 0
        rollout_buffer = BasicBuffer()

        for _ in range(n_steps):
            action, add_info = agent.act_forward(obs, mode=mode)
            next_state, next_obs, reward, _ = env.step(action)
            if mode == "train":
                rollout_buffer.push(state, obs, action, reward, next_state, next_obs, add_info)
            rollout_return += reward
            state = next_state.copy()
            obs = next_obs.copy()
        return rollout_return, rollout_buffer

    obs_dim, action_dim = 4, 2
    seed = 1
    env_str = "PointMass"
    env_params = {"start_loc": [1.0, 1.0, 0.0, 0.0], "init_std": 0.2, "step_std": 0.05, "stochasticity": 1.0}
    agent_params = {
        "gamma": 0.95,
        "model_str": "pointmass_v1_model",
        "opt_params": {"cost_defn": ["fullW", "fullR"], "cost_wt": [[1.0, 1.0, 1.0, 1.0], [0.1, 0.1]], "horizon": 10},
        "eps": 0.25,
        "learning_params": {
            "lr": 3e-4,
            "tr": 0.2,
            "train_params": {"iterations": 50, "batch_size": 32},
            "constrained_updates": True,
        },
    }
    n_iterations = 50
    n_trains = 1
    n_evals = 0
    n_steps = 50
    max_len_buffer = 50

    # Experiment init
    env = getattr(pointmass, env_str)("PointMass", env_params, seed)
    replay_buffer = ReplayBuffer(max_len_buffer, seed)

    # Agent init
    # agent = MPCfunapprox_ex(agent_params, seed)
    agent = MPC(agent_params, seed)

    # Test run
    _, obs = env.reset()
    agent.reset(obs)

    # rollout_return, rollout_buffer = rollout_sample(env, agent, n_steps=50, mode="train")

    # main loop

    sim_res = {
        "state": np.zeros((n_steps, agent.ocp_solver.acados_ocp.dims.nx)),
        "action": np.zeros((n_steps, agent.ocp_solver.acados_ocp.dims.nu)),
    }

    sim_res["state"][0, :] = obs

    for step in range(n_steps - 1):
        sim_res["action"][step], _ = agent.act_forward(sim_res["state"][step])
        _, sim_res["state"][step + 1], reward, _ = env.step(sim_res["action"][step])

    # Plot results
    fig, ax = plt.subplots(nrows=2, ncols=1, sharex=True)
    ax[0].plot(range(n_steps), sim_res["state"][:, 0], label="x")
    ax[0].plot(range(n_steps), sim_res["state"][:, 1], label="y")
    ax[0].legend()
    ax[1].step(range(n_steps), sim_res["action"][:, 0], label="u1")
    ax[1].step(range(n_steps), sim_res["action"][:, 1], label="u2")
    ax[1].legend()
    ax[1].set_xlabel("time")
    ax[0].set_ylabel("state")
    ax[1].set_ylabel("action")
    ax[0].grid(True)
    ax[1].grid(True)
    plt.show()


if __name__ == "__main__":
    test_closed_loop()

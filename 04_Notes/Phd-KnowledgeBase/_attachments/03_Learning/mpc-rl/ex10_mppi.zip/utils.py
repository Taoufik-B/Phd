from collections import UserDict, defaultdict


class AverageMeter(UserDict):
    def __init__(self):
        super().__init__(defaultdict)
        self.counter = 0

    def append()

    

#include <casadi/casadi.hpp>
#include <fstream>
#include <iostream>
#include <math.h>
#include <vector>

casadi::MX
f(const casadi::MX &x, const casadi::MX &u, double v, double L)
{
    return vertcat(v * casadi::MX::cos(x(2)), v * casadi::MX::sin(x(2)), v * casadi::MX::tan(u) / L);
}

int
main(int, char **)
{
    double L = 1.5;          // Wheel base (m)
    double v = 15;           // Constant velocity (m/s)
    double u_max = M_PI / 4; // Maximum steering angle (rad)

    std::vector<double> state_i = {0., 0., 0.};
    std::vector<double> state_f = {10., 3., 0.};

    // Parameters for collocation
    int N = 75; // Number of elements
    int nx = 3; // Degree of state vector
    int Nc = 3; // Degree of interpolation polynomials

    casadi::Opti opti = casadi::Opti();

    casadi::Slice all;
    casadi::MX X = opti.variable(nx, N + 1);
    auto pos_x = X(0, all);
    auto pos_y = X(1, all);
    auto ang_th = X(2, all);

    casadi::MX U = opti.variable(N, 1);
    casadi::MX T = opti.variable(1);
    casadi::MX dt = T / N;

    // Set initial guess values of variables
    opti.set_initial(T, 0.1);
    opti.set_initial(U, 0.);
    opti.set_initial(pos_x, casadi::DM::linspace(state_i[0], state_f[0], N + 1));
    opti.set_initial(pos_y, casadi::DM::linspace(state_i[1], state_f[1], N + 1));

    // Define collocation polynomials
    std::vector<double> tau = casadi::collocation_points(Nc, "radau");
    std::vector<double> D;
    std::vector<std::vector<double>> C;
    casadi::collocation_interpolators(tau, C, D);

    // Constraints in collocation points
    for (int k = 0; k < N; k++) {
        casadi::MX Xc = opti.variable(nx, Nc);
        casadi::MX X_kc = casadi::MX::horzcat({X(all, k), Xc});
        for (int j = 0; j < Nc; j++) {
            casadi::MX fo = f(Xc(all, j), U(k, all), v, L);
            opti.subject_to(casadi::MX::mtimes(X_kc, C[j + 1]) == dt * fo);
        }
        opti.subject_to(X_kc(all, Nc) == X(all, k + 1));
    }

    // Input constraints
    for (int k = 0; k < N; k++) {
        opti.subject_to(U(k) <= u_max);
        opti.subject_to(-u_max <= U(k));
    }

    // Terminal constraints
    opti.subject_to(T >= 0.001);
    opti.subject_to(X(all, 0) == state_i);
    opti.subject_to(X(all, N) == state_f);

    // Loss function
    double alpha = 1;
    opti.minimize(T + alpha * casadi::MX::sumsqr(U));

    // Solve
    casadi::Dict solver_options = {{"print_level", 5}};
    opti.solver("ipopt", {{"ipopt", solver_options}});

    casadi::OptiSol sol = opti.solve();

    // Write solution data to a csv file
    std::ofstream file("mprims_intro_data.csv");
    casadi::DM tt = casadi::DM::linspace(0, sol.value(T), N);
    file << "t,x,y,u\n";
    for (int i = 0; i < N; i++) {
        file << tt(i) << ", " << sol.value(pos_x(i)) << ", " << sol.value(pos_y(i)) << ", " << sol.value(U(i))
             << std::endl;
    }
}

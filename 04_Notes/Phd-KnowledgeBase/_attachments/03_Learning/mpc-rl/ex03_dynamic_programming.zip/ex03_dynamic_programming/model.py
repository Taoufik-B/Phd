import numpy as np
from casadi import SX, Function, jacobian


class  Model():

    def __init__(self, x_expr, u_expr, f_expr, x_steady_state, u_steady_state, name='model', dt=1):
        self.name = name

        self.dt = dt

        self.x_steady_state = x_steady_state
        self.u_steady_state = u_steady_state

        self.x_expr = x_expr
        self.u_expr = u_expr

        self.f_expr = f_expr
        self.f = Function('f', [x_expr, u_expr], [f_expr])

        self.J_x = Function('J_x', [x_expr, u_expr], [jacobian(f_expr, x_expr)])
        self.J_u = Function('J_x', [x_expr, u_expr], [jacobian(f_expr, u_expr)])

        self.nx = x_expr.shape[0]
        self.nu = u_expr.shape[0]


    def simulate(self, x0, u0, w0=0.0):

        x1 = np.reshape(self.f(x0, u0).full(), (self.nx, 1)) + w0

        return x1

    def simulate_traj(self, x0, u_traj):

        N_sim = u_traj.shape[1]

        x_traj = np.zeros((self.nx, N_sim+1))
        x_traj[:, [0]] = x0

        for n in range(N_sim):
            x1 = self.simulate(x_traj[:, n], u_traj[:, n])
            x_traj[:, [n+1]] = x1

        return x_traj

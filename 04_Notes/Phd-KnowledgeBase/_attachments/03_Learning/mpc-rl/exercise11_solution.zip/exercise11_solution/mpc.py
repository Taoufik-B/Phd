import numpy as np

from mpc_formulation import MPCFormulation
import pointmass


class MPCfunapprox(MPCFormulation):
    def __init__(self, agent_params, seed=1):
        # Parameters
        self._parse_agent_params(**agent_params)

        # Model init
        self.model = getattr(pointmass, self.model_str)()
        self.obs_dim = self.model.obs_space.shape[0]
        self.action_dim = self.model.action_space.shape[0]

        # Actor initilizaiton
        super().__init__(self.model, self.opt_params, self.gamma)

        # Seeded random number generators
        self.rng1 = np.random.default_rng(seed)
        self.rng2 = np.random.default_rng(seed)

        # Parameter values
        self.pf_val = 0.1 * self.rng1.random((self.nPf, 1))
        self.p_val = 0.1 * self.rng1.random((self.nP, 1))

        if "cost_wt" in self.opt_params:
            self.p_val[self.iP_cost[0] : self.iP_cost[1]] = self.cost_model.cost_param_init(self.opt_params["cost_wt"])
        self.pf_val[self.iP_cost[1] :], self.p_val[self.iP_cost[1] :] = self.model.model_param_init()

    def reset(self, obs):
        obs = self.model.get_obs(obs)
        action = np.array(self.action_dim)
        self.X0 = self.model.get_initial_guess(obs, action, self.N)

    def update_X0(self, opt_var):
        # "warm starting" for udpating the initial guess given to the solver
        # based on the last solution
        x0 = opt_var.copy()
        N, an, sn = self.N, self.action_dim, self.obs_dim
        at, st = an * N, sn * N

        x0[: an * (N - 1)] = opt_var[an:at]  # action init
        x0[at : at + sn * (N - 1)] = opt_var[at + sn : at + st]  # state/obs init
        x0[at + st : at + st + sn * (N - 1)] = opt_var[at + st + sn : at + 2 * st]  # sigma init
        return x0    

    def _parse_agent_params(self, model_str, opt_params, gamma):
        self.model_str = model_str
        self.opt_params = opt_params
        self.gamma = gamma

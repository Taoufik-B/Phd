Logs folder:
simu_date_time.log

- must contain information about the simulation
  - based on parameter change/ simulation or scenratio should have an id and small description and or objective
  - used configuration
  - stored data / maps Link
  - stored figures if any

Testing Scenario

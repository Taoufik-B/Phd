# %% %matplotlib
import pandas as pd
import matplotlib.pyplot as plt
from seaborn import despine
import math

# %% Read data
data = pd.read_csv("build/mprims_intro_data.csv")
u_max = math.pi / 4  # Maximum steering angle (rad)
N = data.shape[0]

state_i = [data.x[0], data.y[0]]
state_f = [data.x[N - 1], data.y[N - 1]]
T_opt = data.t.values[-1]

# %% Plot
fig, ax = plt.subplots(1, 2, num=10, clear=True, figsize=(12, 6))
ax[0].plot(data.x, data.y)
ax[0].set_xlabel("x [m]")
ax[0].set_ylabel("y [m]")
despine(ax=ax[0])

ax[1].plot(data.t, data.u * 180 / math.pi)
ax[1].plot(data.t, data.t * 0 + u_max * 180 / math.pi, 'k--')
ax[1].plot(data.t, data.t * 0 - u_max * 180 / math.pi, 'k--')
ax[1].set_xlabel("t [s]")
ax[1].set_ylabel("u")
despine(ax=ax[1])

fig.suptitle((f"Optimal trajectory (T = {T_opt:.2f}) from " +
              f"({state_i[0]}, {state_i[1]}) -- ({state_f[0]}, {state_f[1]})"))

# %%
plt.show()

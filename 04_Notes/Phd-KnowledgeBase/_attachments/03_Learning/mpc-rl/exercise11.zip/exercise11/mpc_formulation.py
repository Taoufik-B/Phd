import numpy as np
import casadi as csd

from quadratic_cost import Quadratic_stage_cost_model


class MPCFormulation:
    """
    Class to setup MPC optimization problems in Casadi
    ...

    Attributes
    ----------
    env : Environment

    obs_dim, action_dim : int
        Dimensions of the state and action spaces

    N : int
        Prediction horizon

    gamma : float
        Discount factor

    etau : float
        IPOPT tuning parameter (mu_target, mu_init)

    cost_defn : list of cost types included in parameterization
        Type of cost function (check implemented types)

    model_defn : {"statespace_fromenv", "casadi_fn_obj_fromenv"}
        Source of the model

    X : symbolic (casadi)
        State variables of optimization

    U : symbolic (casadi)
        Input variables of optimization

    Sigma : symbolc (casadi)
        Slack varaibles for state constraints

    Opt_Vars : [X,U,Sigma]

    Pf : symbolic (casadi)
        Optimization parameters [x0, u0]

    P : symbolic (casadi)
        Learnable Optimization parameters (initialized with 0 here)

    model_dyn : casadi function
        Dynamics equation, A*x + B*u, if state space from env is used

    n_P : int
        Number of parameters to be learned

    stage_cost : method
        Predefined method, such as 'quadratic_cost'


    """

    def __init__(self, model, opt_params, gamma):
        self.N = opt_params["horizon"]
        self.gamma = gamma
        self.etau = 1e-6

        ## Symbolic variables for optimization problem

        # State variables
        self.X = csd.MX.sym("X", self.obs_dim, self.N)

        # Input variables
        self.U = csd.MX.sym("U", self.action_dim, self.N)

        # Slack variables for state bounds
        self.Sigma = csd.MX.sym("Sigma", self.obs_dim, self.N)

        # Optimization variables w = [x, u, sigma]
        self.Opt_Vars = csd.vertcat(
            csd.reshape(self.U, -1, 1),
            csd.reshape(self.X, -1, 1),
            csd.reshape(self.Sigma, -1, 1),
        )

        # Symbolic parameters for optimization problem

        # Number of fixed parameters (Pf = [x0, u0, eps])
        self.nPf = self.obs_dim + 2 * self.action_dim

        # Pf = [x0, u0, eps]
        self.Pf = csd.MX.sym("Pf", self.nPf)  # [Initial state x0, action a, eps] ("fixed" params)

        # Number of learnable parameters
        self.nP = 0

        # Learnable parameters
        self.P = csd.MX.sym("P", 0)

        # Cost definition
        self.stage_cost, self.terminal_cost = self.stage_cost_init(opt_params["cost_defn"])

        # Model definition
        self.model_dyn = self.model_dynamics_init()
        

    def stage_cost_init(self, cost_defn):
        self.cost_model = Quadratic_stage_cost_model(self.model, cost_defn)
        stage_cost = self.cost_model.stage_cost
        terminal_cost = self.cost_model.terminal_cost
        Pf, P = self.cost_model.Pf, self.cost_model.P
        self.Pf = csd.vertcat(self.Pf, Pf)
        self.iPf_cost = [self.nPf, self.nPf + Pf.shape[0]]
        self.nPf += Pf.shape[0]
        self.P = csd.vertcat(self.P, P)
        self.iP_cost = [self.nP, self.nP + P.shape[0]]
        self.nP += P.shape[0]
        return stage_cost, terminal_cost

    def model_dynamics_init(self):
        model_dyn, Pf, P = self.model.get_model()
        self.Pf = csd.vertcat(self.Pf, Pf)
        self.iPf_dyn = [self.nPf, self.nPf + Pf.shape[0]]
        self.nPf += Pf.shape[0]
        self.P = csd.vertcat(self.P, P)
        self.iP_dyn = [self.nP, self.nP + P.shape[0]]
        self.nP += P.shape[0]
        return model_dyn

    def objective_cost(self):
        W = np.ones((1, self.obs_dim)) * 1e2  # penalty for violations

        # Formulating objective and constraints
        # J = csd.mtimes(
        #     self.U[:, 0].T,
        #     self.Pf[
        #         self.obs_dim + self.action_dim : self.obs_dim + 2 * self.action_dim
        #     ],
        # )
        J = 0.0
        J += self.stage_cost(
            self.Pf[: self.obs_dim],
            self.U[:, 0],
            self.Pf[self.iPf_cost[0] : self.iPf_cost[1], :],
            self.P[self.iP_cost[0] : self.iP_cost[1], :],
        )
        for i in range(self.N - 1):
            J += self.gamma ** (i + 1) * (
                self.stage_cost(
                    self.X[:, i],
                    self.U[:, i + 1],
                    self.Pf[self.iPf_cost[0] : self.iPf_cost[1], :],
                    self.P[self.iP_cost[0] : self.iP_cost[1], :],
                )
                + W @ self.Sigma[:, i]
            )

        J += self.gamma**self.N * (
            self.terminal_cost(
                self.X[:, self.N - 1],
                self.Pf[self.iPf_cost[0] : self.iPf_cost[1], :],
                self.P[self.iP_cost[0] : self.iP_cost[1], :],
            )
            + W @ self.Sigma[:, self.N - 1]
        )
        return J

    def equality_constraints(self):
        g = []  # Equality constrainsts init
        xn = self.model_dyn(
            self.Pf[: self.obs_dim],
            self.U[:, 0],
            self.Pf[self.iPf_dyn[0] : self.iPf_dyn[1], :],
            self.P[self.iP_dyn[0] : self.iP_dyn[1], :],
        )
        for i in range(self.N - 1):
            g.append(self.X[:, i] - xn)
            xn = self.model_dyn(
                self.X[:, i],
                self.U[:, i + 1],
                self.Pf[self.iPf_dyn[0] : self.iPf_dyn[1], :],
                self.P[self.iP_dyn[0] : self.iP_dyn[1], :],
            )
        g.append(self.X[:, self.N - 1] - xn)
        return g

    def inequality_constraints(self):
        # Constraint list init
        hu0 = []  # Bounding constraints on u0
        hu = []  # Box constraints on inputs
        hx = []  # Box constraints on states
        hs = []  # Box constraints on sigma

        # State bounds
        lb_x = self.model.obs_space.low[:, None]
        ub_x = self.model.obs_space.high[:, None]
        lb_u = self.model.action_space.low[:, None]
        ub_u = self.model.action_space.high[:, None]

        hu0.append(lb_u - self.U[:, 0])
        hu0.append(self.U[:, 0] - ub_u)
        for i in range(self.N - 1):
            hx.append(lb_x - self.X[:, i] - self.Sigma[:, i])
            hx.append(self.X[:, i] - ub_x - self.Sigma[:, i])
            hs.append(-self.Sigma[:, i])
            hu.append(lb_u - self.U[:, i + 1])
            hu.append(self.U[:, i + 1] - ub_u)
        hx.append(lb_x - self.X[:, self.N - 1] - self.Sigma[:, self.N - 1])
        hx.append(self.X[:, self.N - 1] - ub_x - self.Sigma[:, self.N - 1])
        hs.append(-self.Sigma[:, self.N - 1])
        return hu0, hu, hx, hs

import numpy as np
import casadi as csd
import matplotlib.pyplot as plt
from gymnasium.spaces.box import Box

# PointMass: basic pointmass env
# PointMass_v2: pointmass env with added penalty
# pointmass_v0_model: fixed model for MPC formulation 
# pointmass_v1_model: parameteric model for MPC formulation 

class PointMass():
    """
    Class for the pointmass environment
    ...

    Attributes
    ----------
    observation_space : Box
        State constraint set

    action_space: Box
        Input constraint set

    threshold : float
        Norm of distance from goal state to consider reached

    difficulty: {"easy" , "hard"}
        Set difficulty level by modifying threshold for the problem

    dt : float
        Sampling time

    m : float
        mass

    beta : float
        colored noise parameter

    viewer:
        Figure object for rendering

    goal_state: array
        Target where reward is maximum

    goal_mask: array
        Scaling applied on the reward

    seed: int, default 5
        Seed for random number generator

    init_std: float, default 0.1
        Standard deviation for initial states and noise (if not colored)

    reward_style: {1, -1}
        Cost function if positive, Reward function if negative

    model_error: float, default 0.0
        Scaling factor for random error in A, B, S matrices

    stochasticity: float, default 0.0
        Scaling factor for noise acting on true system

    colored_noise: {False, True}
        Choose between Gaussian and colored noise

    render_fl = {False, True}
        Render flag

    supports_rendering = {True, False}


    # Private attributes
    _A : state matrix
    _B : input matrix
    _S : solution to DARE

    """

    supports_rendering = True

    def __init__(self, env_str, env_params, seed):
        """
        Constructor for the class

        Parameters
        ----------
        env_params :
            A dict with environment parameters specified. The default is {}.

        """
        self.env_str = env_str
        self.state = None
        self.obs = None

        # State and action space
        self.state_space = Box(
            low=np.array([-2.0, -2.0, -10.0, -10.0]),
            high=np.array([2.0, 2.0, 10.0, 10.0], dtype=np.float32),
        )
        self.observation_space = Box(
            low=np.array([-2.0, -2.0, -10.0, -10.0]),
            high=np.array([2.0, 2.0, 10.0, 10.0], dtype=np.float32),
        )
        self.action_space = Box(low=-1.0, high=1.0, shape=(2,), dtype=np.float32)

        # Env params
        self._parse_env_params(**env_params)

        # Seeding and random number gen
        self.rng = np.random.default_rng(seed)
        self.rng1 = np.random.default_rng(self.rng.integers(1000))
        self.rng2 = np.random.default_rng(self.rng.integers(1000))

        # Goal definitions
        self.goal_state = np.array([0.0, 0.0, 0.0, 0.0])
        self.goal_mask_s = np.array([3.0, 3.0, 1.0, 1.0])
        self.goal_mask_a = np.array([0.1, 0.1])
        self._W = np.diag(self.goal_mask_s**2)
        self._R = np.diag(self.goal_mask_a**2)
        self.viewer = None
        self.dt = 0.1
        self.m = 1.0

        # Env Dynamics
        self.A = np.array(
            [
                [1.0, 0.0, self.dt, 0.0],
                [0.0, 1.0, 0.0, self.dt],
                [0.0, 0.0, 0.9, 0.0],
                [0.0, 0.0, 0.0, 0.9],
            ]
        )
        self.B = np.array(
            [[0.0, 0.0], [0.0, 0.0], [self.dt / self.m, 0.0], [0.0, self.dt / self.m]]
        )

        # Initiate state
        self.reset()

    def reset(self):
        """
        Resets the state of the system and the noise generator

        Returns the state of the system
        """
        self.state = np.array(self.start_loc)
        self.state[:2] += self.rng1.uniform(-self.init_std, self.init_std, size=2)
        self.state = self.state.clip(
            self.observation_space.low, self.observation_space.high
        )
        self.state_prev = self.state.copy()
        self.obs = self.state.copy()
        return self.state, self.obs

    def step(self, action):
        """
        Simulate one timestep of the environment

        Parameters
        ----------
        action : action taken by agent


        Returns
        -------
        state: array
            state of the system after timestep.
        rew : float
            reward obtained
        done : {0,1}
            0 if target not reached. 1 if reached
        info :

        """
        self.state_prev = self.state.copy()
        self.state = (
            self.A.dot(self.state.T) + self.B.dot(action.T) + self.stochasticity * self.rng2.normal(scale=self.step_std, size=4)
        )

        # self.state = self.state.clip(
        #     self.observation_space.low, self.observation_space.high
        # )
        self.obs = self.state.copy()

        rew = self.reward_fn(self.state_prev, action)
        info = ""
        return (self.state, self.obs, rew, info)

    def reward_fn(self, state, action):
        """
        Compute reward for one timestep

        """
        state = state if state is not None else self.state.copy()
        r = state @ self._W @ state + action @ self._R @ action
        return r

    def _parse_env_params(
        self,
        start_loc=[1.0, 1.0, 0.0, 0.0],
        init_std=0.2,
        step_std=0.0,
        stochasticity=0.0,
        render=False,
    ):
        """Parse simulation parameters"""
        self.start_loc = start_loc
        self.init_std = init_std
        self.step_std = step_std
        self.stochasticity = stochasticity
        self.render_fl = render

    # Rendering functions
    def render(self):
        if self.viewer is None:
            self.viewer = plt.figure("PointMass")
            plt.axis(
                [
                    self.observation_space.low[0],
                    self.observation_space.high[0],
                    self.observation_space.low[1],
                    self.observation_space.high[1],
                ]
            )
            plt.scatter(0, 0, alpha=0.5, c="g", marker="x")
            self.st = plt.scatter(self.state[0], self.state[1], c="b")
            plt.ion()
            plt.show()
            self.st.remove()

        plt.scatter(0, 0, alpha=0.5, c="g", marker="x")
        self.st = plt.scatter(self.state[0], self.state[1], c="b")
        plt.draw()
        plt.pause(0.001)
        self.st.remove()

    def end_render(self):
        plt.scatter(0, 0, alpha=0.5, c="g", marker="x")
        plt.scatter(self.state[0], self.state[1], c="b")
        plt.draw()
        plt.pause(0.001)


class PointMass_v2(PointMass):
    def __init__(self, env_str, env_params, seed):
        super().__init__(env_str, env_params, seed)

        # Update baseline cost
        self.goal_state = np.array([0.0, 0.0, 0.0, 0.0])
        self.goal_mask_s = np.array([3.0, 3.0, 1.0, 1.0])
        self.goal_mask_a = np.array([0.1, 0.1])
        self._W = np.diag(self.goal_mask_s**2)
        self._R = np.diag(self.goal_mask_a**2)

    def reward_fn(self, state, action):
        r = state @ self._W @ state + action @ self._R @ action
        if state[0] <= 0.0:
            r = -100.0 * state[0]
        return r


class pointmass_v0_model:
    # Basic pointmass model
    def __init__(self):
        # State and action space
        self.obs_space = Box(
            low=np.array([-2.0, -2.0, -10.0, -10.0]),
            high=np.array([2.0, 2.0, 10.0, 10.0], dtype=np.float32),
        )
        self.action_space = Box(low=-1.0, high=1.0, shape=(2,), dtype=np.float32)

        # Model dynamics
        self.dt = 0.1
        self.m = 1.0
        self.A = np.array(
            [
                [1.0, 0.0, self.dt, 0.0],
                [0.0, 1.0, 0.0, self.dt],
                [0.0, 0.0, 0.9, 0.0],
                [0.0, 0.0, 0.0, 0.9],
            ]
        )
        self.B = np.array(
            [[0.0, 0.0], [0.0, 0.0], [self.dt / self.m, 0.0], [0.0, self.dt / self.m]]
        )

    def get_obs(self, obs):
        return obs

    def init_ref_state(self, s_ref):
        return np.zeros((self.obs_space.shape[0], 1))

    def get_model(self):
        # Symabolic defn
        Pf = csd.MX.sym("Pf", 0)
        P = csd.MX.sym("Pf", 0)
        x = csd.MX.sym("x", 4)
        u = csd.MX.sym("u", 2)

        # Model of system dynamics
        model_dyn = csd.Function(
            "model_dyn",
            [x, u, Pf, P],
            [csd.mtimes(self.A, x) + csd.mtimes(self.B, u)],
        )
        return model_dyn, Pf, P

    def model_param_init(self):
        return np.zeros((0,1)), np.zeros((0,1))

    def get_initial_guess(self, obs, action, N):
        """
        Generates initial guess for solver

        Parameters
        ----------
        N : int
            Prediction horizon
        """
        X0 = np.array(
            [[0.0, 0.0] * N + [0.0, 0.0, 0.0, 0.0] * N + [0.0, 0.0, 0.0, 0.0] * N]
        ).T
        return X0


class pointmass_v1_model(pointmass_v0_model):
    # Model with symoblic transition dynamics
    # Used for learning transition dynamics
    def __init__(self):
        super().__init__()

    def model_param_init(self):
        bias = np.zeros((4,1))
        return np.zeros((0,1)), 10*np.concatenate((self.A.T.reshape((16, 1)), self.B.T.reshape((8, 1)), bias))

    def get_model(self):
        # Symabolic defn
        Pf = csd.MX.sym("Pf", 0)
        P = csd.MX.sym("P", 28)
        A = 0.1 * csd.reshape(P[:16], 4, 4)
        B = 0.1 * csd.reshape(P[16:24], 4, 2)
        bias = 0.1 * csd.reshape(P[24:], 4, 1) 
        x = csd.MX.sym("x", 4)
        u = csd.MX.sym("u", 2)
        model_dyn_sym = csd.Function(
            "model_dyn_sym", [x, u, Pf, P], [csd.mtimes(A, x) + csd.mtimes(B, u)+bias]
        )
        return model_dyn_sym, Pf, P


if __name__ == "__main__":
    env = PointMass("PointMass", {}, 1)
    env.render()

    s = env.reset()
    print(s)

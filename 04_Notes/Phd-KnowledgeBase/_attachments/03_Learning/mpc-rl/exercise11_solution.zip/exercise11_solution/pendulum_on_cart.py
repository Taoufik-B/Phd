"""
    Pendulum on cart system from ex07_acados.
"""

from casadi import SX, vertcat, sin, cos, Function

from typing import Union

from acados_template import AcadosModel

import numpy as np

from acados_template import AcadosModel, AcadosOcp, AcadosOcpSolver, AcadosSimSolver
import numpy as np
import scipy.linalg as scipylinalg


def export_parametric_pendulum_ode_model() -> AcadosModel:
    model_name = "pendulum_ode"
    # constants
    M = SX.sym("M")  # mass of the cart [kg]
    m = 0.1  # mass of the ball [kg]
    g = 9.81  # gravity constant [m/s^2]
    l = 0.8  # length of the rod [m]

    # set up states & controls
    p = SX.sym("p")
    theta = SX.sym("theta")
    v = SX.sym("v")
    omega = SX.sym("omega")

    x = vertcat(p, theta, v, omega)

    F = SX.sym("F")
    u = vertcat(F)

    # xdot
    p_dot = SX.sym("p_dot")
    theta_dot = SX.sym("theta_dot")
    v_dot = SX.sym("v_dot")
    omega_dot = SX.sym("omega_dot")

    xdot = vertcat(p_dot, theta_dot, v_dot, omega_dot)

    # algebraic variables
    # z = None

    # parameters
    param = M

    # dynamics
    cos_theta = cos(theta)
    sin_theta = sin(theta)
    denominator = M + m - m * cos_theta * cos_theta
    f_expl = vertcat(
        v,
        omega,
        (-m * l * sin_theta * omega * omega + m * g * cos_theta * sin_theta + F) / denominator,
        (-m * l * cos_theta * sin_theta * omega * omega + F * cos_theta + (M + m) * g * sin_theta) / (l * denominator),
    )

    f_impl = xdot - f_expl

    model = AcadosModel()

    model.f_impl_expr = f_impl
    model.f_expl_expr = f_expl
    model.x = x
    model.xdot = xdot
    model.u = u
    # model.z = z
    model.p = param
    model.name = model_name

    return model


def export_parameter_augmented_pendulum_ode_model() -> AcadosModel:
    model_name = "parameter_augmented_pendulum_ode"

    # constants
    # M = 1.0  # mass of the cart [kg]
    # m = 0.1  # mass of the ball [kg]
    # g = 9.81  # gravity constant [m/s^2]
    # l = 0.8  # length of the rod [m]

    M = SX.sym("M")  # mass of the cart [kg]
    m = SX.sym("m")  # mass of the ball [kg]
    g = SX.sym("g")  # gravity constant [m/s^2]
    l = SX.sym("l")  # length of the rod [m]

    nparam = 4

    # set up states & controls
    p = SX.sym("p")
    theta = SX.sym("theta")
    v = SX.sym("v")
    omega = SX.sym("omega")

    x = vertcat(p, theta, v, omega, M, m, g, l)

    F = SX.sym("F")
    u = vertcat(F)

    # xdot
    p_dot = SX.sym("p_dot")
    theta_dot = SX.sym("theta_dot")
    v_dot = SX.sym("v_dot")
    omega_dot = SX.sym("omega_dot")
    M_dot = SX.sym("M_dot")
    m_dot = SX.sym("m_dot")
    g_dot = SX.sym("g_dot")
    l_dot = SX.sym("l_dot")

    xdot = vertcat(p_dot, theta_dot, v_dot, omega_dot, M_dot, m_dot, g_dot, l_dot)

    # algebraic variables
    # z = None

    # parameters
    param = []

    # dynamics
    cos_theta = cos(theta)
    sin_theta = sin(theta)
    denominator = M + m - m * cos_theta * cos_theta
    f_expl = vertcat(
        v,
        omega,
        (-m * l * sin_theta * omega * omega + m * g * cos_theta * sin_theta + F) / denominator,
        (-m * l * cos_theta * sin_theta * omega * omega + F * cos_theta + (M + m) * g * sin_theta) / (l * denominator),
        0.0,
        0.0,
        0.0,
        0.0,
    )

    f_impl = xdot - f_expl

    model = AcadosModel()

    model.f_impl_expr = f_impl
    model.f_expl_expr = f_expl
    model.x = x
    model.xdot = xdot
    model.u = u
    # model.z = z
    model.p = param
    model.name = model_name

    return model, nparam


def ERK4(
    f: Union[SX, Function], x: Union[SX, np.ndarray], u: Union[SX, np.ndarray], p: Union[SX, np.ndarray], h: float
) -> Union[SX, np.ndarray]:
    """
    Explicit Runge-Kutta 4 integrator

    TODO: Works for numeric values as well as for symbolic values. Type hinting is a bit misleading.

    Parameters:
        f: function to integrate
        x: state
        u: control
        p: parameters
        h: step size

        Returns:
            xf: integrated state
    """

    # Check if f has type SX
    if isinstance(f, SX):
        f = Function("f", [x, u, p], [f])

    k1 = f(x, u, p)
    k2 = f(x + h / 2 * k1, u, p)
    k3 = f(x + h / 2 * k2, u, p)
    k4 = f(x + h * k3, u, p)
    xf = x + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

    return xf


def ERK4_no_param(
    f: Union[SX, Function], x: Union[SX, np.ndarray], u: Union[SX, np.ndarray], h: float
) -> Union[SX, np.ndarray]:
    """
    Explicit Runge-Kutta 4 integrator

    TODO: Works for numeric values as well as for symbolic values. Type hinting is a bit misleading.

    Parameters:
        f: function to integrate
        x: state
        u: control
        h: step size

        Returns:
            xf: integrated state
    """

    # Check if f has type SX
    if isinstance(f, SX):
        f = Function("f", [x, u], [f], ["x", "u"], ["xf"])

    k1 = f(x, u)
    k2 = f(x + h / 2 * k1, u)
    k3 = f(x + h / 2 * k2, u)
    k4 = f(x + h * k3, u)
    xf = x + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

    return xf


def export_parametric_ocp(x0=np.array([0.0, np.pi / 6, 0.0, 0.0]), N_horizon=50, T_horizon=2.0, Fmax=80.0) -> AcadosOcp:
    # create ocp object to formulate the OCP
    ocp = AcadosOcp()

    # set model
    model = export_parametric_pendulum_ode_model()

    # Use a discrete dynamics model
    model.disc_dyn_expr = ERK4(model.f_expl_expr, model.x, model.u, model.p, T_horizon / N_horizon)

    ocp.parameter_values = np.array([1.0])
    ocp.model = model

    # set dimensions
    ocp.dims.N = N_horizon
    nu = ocp.model.u.size()[0]
    nx = ocp.model.x.size()[0]

    # set cost
    Q_mat = 2 * np.diag([1e3, 1e3, 1e-2, 1e-2])
    R_mat = 2 * np.diag([1e-1])

    # We use the NONLINEAR_LS cost type and GAUSS_NEWTON Hessian approximation - One can also use the external cost module to specify generic cost.
    ocp.cost.cost_type = "NONLINEAR_LS"
    ocp.cost.cost_type_e = "NONLINEAR_LS"
    ocp.cost.W = scipylinalg.block_diag(Q_mat, R_mat)
    ocp.cost.W_e = Q_mat

    ocp.model.cost_y_expr = vertcat(model.x, model.u)
    ocp.model.cost_y_expr_e = model.x
    ocp.cost.yref = np.zeros((nx + nu,))
    ocp.cost.yref_e = np.zeros((nx,))

    # set constraints
    ocp.constraints.lbu = np.array([-Fmax])
    ocp.constraints.ubu = np.array([+Fmax])
    ocp.constraints.idxbu = np.array([0])

    ocp.constraints.x0 = x0

    # set options
    ocp.solver_options.qp_solver = "PARTIAL_CONDENSING_HPIPM"  # FULL_CONDENSING_QPOASES
    # PARTIAL_CONDENSING_HPIPM, FULL_CONDENSING_QPOASES, FULL_CONDENSING_HPIPM,
    # PARTIAL_CONDENSING_QPDUNES, PARTIAL_CONDENSING_OSQP, FULL_CONDENSING_DAQP
    ocp.solver_options.hessian_approx = "GAUSS_NEWTON"  # 'GAUSS_NEWTON', 'EXACT'
    ocp.solver_options.integrator_type = "DISCRETE"
    # ocp.solver_options.print_level = 1
    ocp.solver_options.nlp_solver_type = "SQP"  # SQP_RTI, SQP
    ocp.solver_options.nlp_solver_max_iter = 400
    # ocp.solver_options.levenberg_marquardt = 1e-4

    # set prediction horizon
    ocp.solver_options.tf = T_horizon

    return ocp


def export_parameter_augmented_ocp(
    x0=np.array([0.0, np.pi / 6, 0.0, 0.0, 1.0]), N_horizon=50, T_horizon=2.0, Fmax=80.0
) -> AcadosOcp:
    # create ocp object to formulate the OCP
    ocp = AcadosOcp()

    # set model
    model, nparam = export_parameter_augmented_pendulum_ode_model()

    # # Use a discrete dynamics model
    # model.disc_dyn_expr = ERK4_no_param(model.f_expl_expr, model.x, model.u, T_horizon / N_horizon)

    # ocp.parameter_values = np.array([1.0])
    ocp.model = model

    # set dimensions
    ocp.dims.N = N_horizon
    nu = ocp.model.u.size()[0]
    nx = ocp.model.x.size()[0]

    # set cost
    Q_mat = 2 * np.diag([1e3, 1e3, 1e-2, 1e-2])
    R_mat = 2 * np.diag([1e-1])

    # We use the NONLINEAR_LS cost type and GAUSS_NEWTON Hessian approximation - One can also use the external cost module to specify generic cost.
    ocp.cost.cost_type = "NONLINEAR_LS"
    ocp.cost.cost_type_e = "NONLINEAR_LS"
    ocp.cost.W = scipylinalg.block_diag(Q_mat, R_mat)
    ocp.cost.W_e = Q_mat

    ocp.model.cost_y_expr = vertcat(model.x[:-nparam], model.u)
    ocp.model.cost_y_expr_e = model.x[:-nparam]
    ocp.cost.yref = np.zeros((nx - nparam + nu,))
    ocp.cost.yref_e = np.zeros((nx - nparam,))

    # set constraints
    ocp.constraints.lbu = np.array([-Fmax])
    ocp.constraints.ubu = np.array([+Fmax])
    ocp.constraints.idxbu = np.array([0])

    ocp.constraints.x0 = x0

    # set options
    ocp.solver_options.qp_solver = "PARTIAL_CONDENSING_HPIPM"  # FULL_CONDENSING_QPOASES
    # PARTIAL_CONDENSING_HPIPM, FULL_CONDENSING_QPOASES, FULL_CONDENSING_HPIPM,
    # PARTIAL_CONDENSING_QPDUNES, PARTIAL_CONDENSING_OSQP, FULL_CONDENSING_DAQP
    ocp.solver_options.hessian_approx = "GAUSS_NEWTON"  # 'GAUSS_NEWTON', 'EXACT'
    ocp.solver_options.integrator_type = "IRK"  # "DISCRETE"
    # ocp.solver_options.print_level = 1
    ocp.solver_options.nlp_solver_type = "SQP"  # SQP_RTI, SQP
    ocp.solver_options.nlp_solver_max_iter = 400
    # ocp.solver_options.levenberg_marquardt = 1e-4

    # set prediction horizon
    ocp.solver_options.tf = T_horizon

    return ocp

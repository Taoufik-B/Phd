import numpy as np
import casadi as csd


class Quadratic_stage_cost_model:
    def __init__(self, model, cost_defn) -> None:
        self.model = model
        self.obs_dim = model.obs_space.shape[0]
        self.action_dim = model.action_space.shape[0]
        self.cost_defn = cost_defn
        self.stage_cost = self.quadratic_stage_cost
        self.terminal_cost = self.quadratic_terminal_cost

        # Cost parameters init
        self.Pf = csd.MX.sym("Pf", 0)
        self.P = csd.MX.sym("P", 0)
        self.cost_parameterization()
        # self.params_torch = self.cost_parameterization_torch()

    def quadratic_stage_cost(self, state, act, pf, p):
        s = state - self.sref_fn(p)
        cost = (
            csd.mtimes([s.T, self.W_fn(p), s])
            + csd.mtimes([s.T, self.w_fn(p)])
            + csd.mtimes([act.T, self.R_fn(p), act])
            + self.b_fn(p)
        )
        # if state[0] < 0.0:
        #     cost += self.c1_fn * state[0]
        return cost

    def quadratic_terminal_cost(self, state, pf, p):
        s = state - self.sref_fn(p)
        cost = csd.mtimes([s.T, self.tW_fn(p), s]) + csd.mtimes([s.T, self.tw_fn(p)])
        # if state[0] < 0.0:
        #     cost += self.c1_fn * state[0]
        return cost

    def cost_parameterization(self):
        """
        Create a parameterization of the MPC cost function.
        Initialize the parameterization with quadratic stage cost and
        euclidean_dist terminal cost. For each cost type in cost_defn,
        corresponding attributes are created/updated (indP_b for "bias" etc).

        Returns
        sref : Reference state
        WW : State weight matrix.
        w : Linear weight matrix.
        b : Bias term
        RR : Action weight matrix.
        tWW: Terminal state weight matrix.
        tw: Terminal linear matrix.

        """

        # Cost formulation
        scale = 0.1
        sref = 10*self.model.init_ref_state(np.zeros((self.obs_dim, 1)))
        WW = np.zeros((self.obs_dim, self.obs_dim))
        w = np.zeros((self.obs_dim))
        RR = np.zeros((self.action_dim, self.action_dim))
        b = 0.0
        tWW = np.eye(self.obs_dim)
        tw = np.zeros((self.obs_dim))

        for cost_type in self.cost_defn:
            if cost_type == "bias":
                P_b = csd.MX.sym("P_b", 1)
                b = P_b
                self.P = csd.vertcat(self.P, P_b)

            elif cost_type == "sref":
                sref = csd.MX.sym("P_sref", self.obs_dim)
                self.P = csd.vertcat(self.P, sref)

            elif cost_type == "w":
                P_lw = csd.MX.sym("P_lw", self.obs_dim)
                w = P_lw
                self.P = csd.vertcat(self.P, P_lw)

            elif cost_type == "diagW":
                P_w = csd.MX.sym("P_w", self.obs_dim)
                W = csd.diag(P_w)
                WW = W.T @ W
                self.P = csd.vertcat(self.P, P_w)

            elif cost_type == "diagR":
                P_r = csd.MX.sym("P_r", self.action_dim)
                R = csd.diag(P_r)
                RR = R.T @ R
                self.P = csd.vertcat(self.P, P_r)

            elif cost_type == "fullW":
                # casadi function for constructing upper triangular matrix
                U = csd.SX.sym("U", csd.Sparsity.lower(self.obs_dim))
                u = csd.vertcat(*U.nonzeros())
                W_upper = csd.Function("Lower_tri_W_from_param", [u], [U])

                P_fwu = csd.MX.sym("P_fwu", int(self.obs_dim * (self.obs_dim + 1) / 2))
                W = W_upper(P_fwu)
                WW = W.T @ W
                self.P = csd.vertcat(self.P, P_fwu)

            elif cost_type == "fullR":
                # casadi function for constructing upper triangular matrix
                U = csd.SX.sym("U", csd.Sparsity.lower(self.action_dim))
                u = csd.vertcat(*U.nonzeros())
                R_upper = csd.Function("Lower_tri_R_from_param", [u], [U])

                P_fru = csd.MX.sym(
                    "P_fru", int(self.action_dim * (self.action_dim + 1) / 2)
                )
                R = R_upper(P_fru)
                RR = R.T @ R
                self.P = csd.vertcat(self.P, P_fru)

            elif cost_type == "diagtW":
                P_tw = csd.MX.sym("P_tw", self.obs_dim)
                tW = csd.diag(P_tw)
                tWW = tW.T @ tW
                self.P = csd.vertcat(self.P, P_tw)

            elif cost_type == "fulltW":
                # casadi function for constructing upper triangular matrix
                U = csd.SX.sym("U", csd.Sparsity.lower(self.obs_dim))
                u = csd.vertcat(*U.nonzeros())
                tW_upper = csd.Function("Lower_tri_tW_from_param", [u], [U])

                P_ftwu = csd.MX.sym(
                    "P_ftwu", int(self.obs_dim * (self.obs_dim + 1) / 2)
                )
                tW = tW_upper(P_ftwu)
                tWW = tW.T @ tW
                self.P = csd.vertcat(self.P, P_ftwu)

            elif cost_type == "tw":
                tw = csd.MX.sym("P_tlw", self.obs_dim)
                self.P = csd.vertcat(self.P, tw)

            else:
                print(cost_type)
                raise BaseException("Cost function type not implemented")

        self.sref_fn = csd.Function("sref_fn", [self.P], [scale*sref])
        self.W_fn = csd.Function("W_fn", [self.P], [WW])
        self.w_fn = csd.Function("w_fn", [self.P], [scale*w])
        self.R_fn = csd.Function("R_fn", [self.P], [RR])
        self.b_fn = csd.Function("b_fn", [self.P], [scale*b])
        self.tW_fn = csd.Function("tW_fn", [self.P], [tWW])
        self.tw_fn = csd.Function("tw_fn", [self.P], [scale*tw])
        return

    def cost_param_init(self, cost_wt):
        p_temp = []
        for i, cost_type in enumerate(self.cost_defn):
            if (
                cost_type == "bias"
                or cost_type == "diagW"
                or cost_type == "diagR"
                or cost_type == "w"
                or cost_type == "sref"
                or cost_type == "diagtW"
            ):
                p_temp += 10*cost_wt[i]
            elif cost_type == "fullW" or cost_type == "fullR" or cost_type == "fulltW":
                tmp = np.diag(cost_wt[i])
                p_temp += list(tmp.T[np.triu_indices(tmp.shape[0])])
        return np.array(p_temp)[:, None]

    def print_params(self, p):
        for cost_type in self.cost_defn:
            if cost_type == "bias":
                print("Bias:")
                print(self.b_fn(p).full())
            elif cost_type == "sref":
                print("State ref:")
                print(self.sref_fn(p).full())
            elif cost_type == "w":
                print("w:")
                print(self.w_fn(p).full())
            elif (
                cost_type == "diagW"
                or cost_type == "fullW"
            ):
                print("W:")
                print(self.W_fn(p).full())
            elif (
                cost_type == "diagR"
                or cost_type == "fullR"
            ):
                print("R:")
                print(self.R_fn(p).full())
            elif (
                cost_type == "diagtW"
                or cost_type == "fulltW"
            ):
                print("terminal W:")
                print(self.tW_fn(p).full())
            elif cost_type == "tw":
                print("terminal w:")
                print(self.tw_fn(p).full())
